<?php
	
	$mysqli->query("CREATE TABLE IF NOT EXISTS `addons` (
	  `id` int(10) NOT NULL AUTO_INCREMENT,
	  `name` varchar(50) NOT NULL,
	  PRIMARY KEY (`id`)
	) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1");
	
	$mysqli->query("ALTER TABLE `private` ADD hunter_guest int(1) NOT NULL DEFAULT '0'");
	$mysqli->query("ALTER TABLE `setting` ADD silent_mode int(1) NOT NULL DEFAULT '0'");
	$mysqli->query("ALTER TABLE `setting` ADD show_topic int(1) NOT NULL DEFAULT '1'");
	$mysqli->query("ALTER TABLE `setting` ADD global_sound int(1) NOT NULL DEFAULT '1'");
	$mysqli->query("ALTER TABLE `users` ADD user_friends text NOT NULL");
	$mysqli->query("UPDATE `setting` SET `version` = '4'");

?>