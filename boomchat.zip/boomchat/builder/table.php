<div id="content_table">
<div class="half_table_left table_zone">
	<h3>Database host</h3>
	<p>host of your database ex: localhost</p>
	<input id="host"></input>
	<h3>Database username</h3>
	<p>Username of db ex: root</p>
	<input id="user"></input>
</div>
<div class="half_table_right table_zone">
	<h3>Database password</h3>
	<p>password to connect to database</p>
	<input id="password"></input>
	<h3>Database name</h3>
	<p>Name of your database</p>
	<input id="name"></input>
	<button id="install_component">Install components</button>
</div>
</div>