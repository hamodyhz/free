<div id="header">
	<div id="install_logo">
		<img src="./css/images/logo/default.png"/>
	</div>
	<div id="install_error">
	</div>
</div>