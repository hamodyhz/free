<div id="content_table">
<div class="half_table_left table_zone">
	<h3>Username</h3>
	<p>max 16 caracters a-z 0-9</p>
	<input id="user_name"></input>
	<h3>Email</h3>
	<p>enter a valid email for your account</p>
	<input id="user_email"></input>
</div>
<div class="half_table_right table_zone">
	<h3>Password</h3>
	<p>Set your password</p>
	<input type="password" id="user_password"></input>
	<h3>Confirm password</h3>
	<p>repeat your password</p>
	<input type="password" id="confirm_password"></input>
	<button id="create_account">Create account</button>
</div>
</div>