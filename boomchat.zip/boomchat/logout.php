<?php
	require_once("system/config.php");
	
	//
	// Logged in checker
	if ($access == 'on'){
		$userlogout = $user['user_name'];
		$passlogout = $user['user_password'];
		setcookie("username","",time() - (1000 * 1000));
		setcookie("password","",time() - (1000 * 1000));
		if ($user['user_access'] == 2){
			$mysqli->query("UPDATE `users` SET `user_access` = '4', `user_status` = '3', `user_kick` = ''  WHERE `user_name` = '{$user["user_name"]}'");
		}
		else {
			if($user['user_status'] != 4){
				$mysqli->query("UPDATE `users` SET `user_status` = '3' WHERE `user_name` = '{$user["user_name"]}'");
			}
		}
	}
	else {
		die();
	}
?>