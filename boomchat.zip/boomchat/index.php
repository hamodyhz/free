<?php
/////////// BoomChat v 1.00 /////////////////
// all right reserved to Robert Barnab�
////////////////////////////////////////////
require_once("system/config.php");

if($chat_install != 1){
	include('builder/installer.php');
	die();
}
$user_ip = $mysqli->real_escape_string($_SERVER['REMOTE_ADDR']);
$checkban = $mysqli->query("SELECT `ip` FROM `banned` WHERE `ip` = '$user_ip'");

if($checkban->num_rows > 0 && $setting['cookie_ban'] == 1 ){
	setcookie("banned","banned",time()+ (1000 * 1000));
}
if (!isset($_COOKIE["banned"])){
	$testcc = 'banok';
}
else {
	$testcc = 'banned';
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
<title><?php echo $setting['title']; ?></title>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="js/jquery-1.9.0.min.js"></script>
<script type="text/javascript" src="system/language/<?php echo $setting['language']; ?>/language.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
<script type="text/javascript" src="js/fancybox/jquery.mousewheel-3.0.6.pack.js"></script>
<script type="text/javascript" src="js/fancybox/jquery.fancybox.js?v=2.1.5"></script>
<script type="text/javascript" src="js/fancybox/javaimage.js"></script>
<script type="text/javascript" src="js/avatar.js"></script>
<link rel="stylesheet" type="text/css" href="js/fancybox/jquery.fancybox.css?v=2.1.5" media="screen" />
<link rel="stylesheet" type="text/css" href="css/main.css" />
<link rel="stylesheet" type="text/css" href="css/panel.css" />
<link rel="stylesheet" type="text/css" href="css/upload.css" />
<link rel="stylesheet" type="text/css" href="css/color_picker.css" />
<link rel="stylesheet" type="text/css" href="css/addons.css" />
<?php if($access == 'on' && $setting['version'] >= 4){
$load_addons = $mysqli->query("SELECT `name` FROM `addons` WHERE `id` > 0");
	if($load_addons->num_rows > 0){
		while ($list_addons = $load_addons->fetch_assoc()){
			echo '<link rel="stylesheet" type="text/css" href="addons/' . $list_addons['name'] . '/css/' . $list_addons['name'] . '.css" />';
		}
	}
}
?>
<link id="active_theme" rel="stylesheet" type="text/css" href="css/themes/<?php if($access == 'on' && $setting['allow_theme'] == 1){ echo $user['user_theme']; } else { echo $setting['default_theme'];} ?>.css" />
<link rel="stylesheet" type="text/css" href="css/chat.css" />
<link rel="stylesheet" type="text/css" href="css/<?php if($setting['orientation'] == 1){ echo 'ads.css'; }else { echo 'ads_reverse.css'; } ?>" />
<link rel="stylesheet" type="text/css" href="css/responsive.css" />
<?php if($setting['orientation'] == 2){ echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"css/reverse.css\" />"; } ?>
<link rel="stylesheet" type="text/css" href="css/style.css" />
<script type="text/javascript">
	var my_username = '<?php if ($access == 'on'){echo $user["user_name"];} ?>';
	var user_rank = '<?php if ($access == 'on'){echo $user["user_rank"];} ?>';
	var user_access = '<?php if ($access == 'on'){echo $user["user_access"];} ?>';
	var user_room = '<?php if ($access == 'on'){echo $user["user_roomid"];} ?>';
	var user_private = "";
	var checkUsername = "";
	var selectedAds = <?php echo $setting['ads_select']; ?>;
	var boxZone = <?php echo $setting['orientation']; ?>;
	var checkScroll = 0;
	var scrollStart = 0;
	var scrollCompare = 0;
	var showTopic = <?php if($setting['version'] >= 4) { echo $setting['show_topic']; } else { echo 1; } ?>;
	var emOn = <?php echo $setting['emoticon']; ?>;
	var whistle = '<?php if($setting['version'] >= 4) { echo $setting['global_sound']; } else { echo 1; } ?>';
</script>
</head>
<body>
<div id="external_wrap">
	<?php 
		if($checkban->num_rows < 1 && $testcc != 'banned'){
			if ($access == 'off'){
					include('control/login.php');
			}
			else {
				if($user['user_status'] == 4){
					$mysqli->query("UPDATE `users` SET `last_action` = '$time', `first_check` = '1', `join_chat` = '1' WHERE `user_name` = '{$user['user_name']}'");
				}
				else {
					$mysqli->query("UPDATE `users` SET `last_action` = '$time', `user_status` = '1', `first_check` = '1', `join_chat` = '1' WHERE `user_name` = '{$user['user_name']}'");
				}
				if ($setting['maintenance'] == 1 || $user['user_rank'] > 2){
					if ($user['user_access'] != 4 && $user['user_access'] != 1) {
						if($user['user_access'] == 2){
							include('control/kicked.php');
						}
						elseif ($user['user_access'] == 0 && $user['user_rank'] < 4){
							include('control/banned.php');
						}
					}
					else{
							if($user['verified'] == 0 && $setting['activation'] == 1 && $user['user_rank'] < 2 && $user['user_guest'] !== 1){
								include('control/activation.php');
							}
							else {
								include('control/full_chat.php');
							}
					}
				}
				else {
					include('control/maintenance.php');
				}
			}
		}
		else{
			if($user['user_rank'] > 3){
				include('control/full_chat.php');
			}
			else {
				include('control/banned.php');
			}
		}
	?>
</div>
</body>
</html>

