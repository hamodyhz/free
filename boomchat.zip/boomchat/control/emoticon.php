<div class="bar_options">
	<div id="emo_item" class="bar_options_item">
		<img id="zoom_emo" src="icon/smile.png"/>
	</div>
</div>
<div class="bar_options">
	<div class="bar_options_item">
		<img src="icon/high.png"/>
	</div>
	<div class="wrap_picker">
		<div id="high_pick" value="high_pick" class="picker">
		</div>
	</div>
</div>
<div class="bar_options">
	<div class="bar_options_item">
		<img src="icon/text.png"/>
	</div>
	<div class="wrap_picker">
		<div id="text_pick" value="text_pick" class="picker">
		</div>
	</div>
</div>
<div class="bar_options">
	<div id="bold_item" value="0" class="text_item bar_options_item">
		<img src="icon/bold.png"/>
	</div>
</div>
<div class="bar_options">
	<div id="italic_item" value="0" class="text_item bar_options_item">
		<img src="icon/italic.png"/>
	</div>
</div>
<div class="bar_options">
	<div id="underline_item" value="0" class="text_item bar_options_item">
		<img src="icon/underline.png"/>
	</div>
</div>