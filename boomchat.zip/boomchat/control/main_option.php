<div class="panels top_panels panelone" id="main_option">
	<div class="top_option bottom_separator">
		<div class="close_option">
				<img class="close_panel" value="main_option" src="./icon/close.png"/>
		</div>
		<div class="inner_top_option">
			<a class="tooltip2" title="<?php echo $tipsettings; ?>">
				<img  title="" id="ad_setting" src="./icon/tool.png"/>
			</a>
			<a class="tooltip2" title="<?php echo $tiprooms; ?>">
				<img  title="" id="ad_room"  src="./icon/rooms.png"/>
			</a>
			<a class="tooltip2" title="<?php echo $tipuser; ?>">
				<img  title="" id="ad_user"  src="./icon/room.png"/>
			</a>
			<a class="tooltip2" title="<?php echo $tipword; ?>">
				<img  title="" id="ad_word"  src="./icon/wordcheck.png"/>
			</a>
		</div>
	</div>
	<div class="panel_element top_separator">
	</div>
	<div class="clear_panel">
	</div>
</div>