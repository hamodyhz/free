<div class="background_login" id="container_kicked">
	<div class="bottom_separator" id="header_login">
	</div>
	<div class="top_separator" id="content_kicked">
		<h1 class="sub_color"><?php echo $maintenance; ?></h1>
		<h2><?php echo $maintenance2; ?></h2>	
	</div>
</div>