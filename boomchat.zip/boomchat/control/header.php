<div id="header">
	<div id="inner_header">
	</div>
</div>