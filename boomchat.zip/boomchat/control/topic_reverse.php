<div id="topic_reverse">
	<div id="room_topic" class="bottom_separator" >
	</div>
	<div class="clear">
	</div>
</div>