<div id="show_chat_ads">
	<div class="myads ads1">
		<?php include('./ads/ad_1.php'); ?>
	</div>
	<div class="myads ads2">
		<?php include('./ads/ad_2.php'); ?>
	</div>
	<div class="myads ads3">
		<?php include('./ads/ad_3.php'); ?>
	</div>
	<div class="myads ads4">
		<?php include('./ads/ad_4.php'); ?>
	</div>
	<div class="myads ads5">
		<?php include('./ads/ad_5.php'); ?>
	</div>
</div>