<div class="panels top_panels panelone"  id="addon_panel">
	<div class="top_option bottom_separator">
		<div class="close_option">
			<img class="close_panel" value="addon_panel" src="./icon/close.png"/>
		</div>
		<div class="inner_top_option">
		</div>
	</div>
	<div class="panel_element top_separator">
	</div>
	<div class="clear_panel">
	</div>
</div>