<div class="background_login" id="container_kicked">
	<div class="bottom_separator" id="header_login">
	</div>
	<div class="top_separator" id="content_kicked">
		<h1 class="sub_color"><?php echo $userbanned; ?></h1>
		<h2><?php echo $userbanned1; ?></h2>	
	</div>
</div>