<div class="panels panelone"  id="users_options">
	<div class="top_option">
		<div class="close_option">
				<img class="close_panel" value="users_options" src="./icon/close.png"/>
		</div>
		<div class="inner_top_option">

		</div>
	</div>
	<div class="panel_element">
	</div>
	<div class="clear_panel">
	</div>
</div>	