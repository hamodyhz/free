<div id="container_login" class="background_login">
	<div id="header_login" class="bottom_separator">
	</div>
	<div id="content_login" class="top_separator">
		<div id="login_error"><div class="error" id="login_error_inside"></div></div>
		<form class="login_form" autocomplete="off">
			<input style="display:none">
			<input type="password" style="display:none">
			<p class="login_label"><?php echo $lang_username; ?></p>
			<input id="user_username" class="input_data background_box" type="text" maxlength="<?php echo $setting['max_username']; ?>" name="username">
			<p class="login_label"><?php echo $lang_password; ?></p>
			<input id="user_password" class="input_data background_box" maxlength="30" type="password" name="password"><br />
			<p class="login_label sub_color forgot_password"><?php echo $lang_forgot; ?></p>
			<div class="sub_button hover_element" id="login_button"><p><?php echo $lang_login; ?></p></div>
			<?php if($setting['registration'] == 1){
			echo "<div id=\"login_register\"><p>$lang_register</p></div>";
			echo "<div class=\"clear\"></div>";
			}
			if($setting['allow_guest'] == 1){
				echo "<div class=\"sub_button hover_element\" id=\"guest_button\"><p>$guest_button</p></div>";
			}
			?>
		</form>
	</div>
</div>
<script type="text/javascript" src="js/login.js"></script>