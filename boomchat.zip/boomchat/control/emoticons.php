<div id="list_emoticon">
	<div id="smile_content">
			<?php listSmilies(); ?>
		<div class="clear"></div>
	</div>
</div>
