<div class="panels panelone"  id="profile_panel">
	<div class="top_option bottom_separator">
		<div class="close_option">
			<img class="close_panel" value="profile_panel" src="./icon/close.png"/>
		</div>
		<div class="inner_top_option">
		</div>
	</div>
	<div class="panel_element top_separator">
	</div>
	<div class="clear_panel">
	</div>
</div>