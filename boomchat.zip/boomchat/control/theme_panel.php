<div class="panels panelone top_panels"  id="theme_panel">
	<div class="top_option bottom_separator">
		<div class="close_option">
			<a class="tooltip3" title="Close">
				<img class="close_panel" value="theme_panel" src="./icon/close.png"/>
			</a>
		</div>
	</div>
	<div class="panel_element top_separator">
	</div>
	<div class="clear_panel">
	</div>
</div>