<div class="background_login" id="container_kicked">
	<div class="bottom_separator" id="header_login">
	</div>
	<div class="top_separator" id="content_kicked">
		<h2><?php echo $kickbox; ?></h2>
		<h3 class="sub_color"><?php echo $kickbox2; ?></h3>
		<p class="reason"><?php echo $user['user_kick']; ?></p>
		<div class="sub_button hover_element" id="kicked_button"><p><?php echo $kickbox3; ?></p></div>		
	</div>
</div>
<script type="text/javascript" src="js/kicked.js"></script>