<div class="panels top_panels paneltwo"  id="history_panel">
	<div class="top_option bottom_separator">
		<div class="close_option">
			<img class="close_panel" value="history_panel" src="./icon/close.png"/>
		</div>
		<div class="inner_top_option">
			<img id="my_history" src="./icon/user_history.png"/>
			<img id="chat_history"  src="./icon/rooms.png"/>
		</div>
	</div>
	<div class="panel_element top_separator">
		<div id="history_container">
		</div>
	</div>
	<div class="clear_panel">
	</div>
</div>