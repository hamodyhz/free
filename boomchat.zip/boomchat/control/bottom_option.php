<div id="my_menu">
	<div id="menu">
		<?php if( $user['user_rank'] > 4 ){
			echo "<div id=\"open_setting\" value=\"main_option\"  class=\"other_panels\">
				<a class=\"tooltip\" title=\"$tipsettings\">
					<img title=\"\" src=\"./icon/setting.png\"/>
				</a>
			</div>";
			}
		?>
		<?php if($user['guest'] < 1){
			echo "<div class=\"account_button other_panels\" value=\"tools_panel\"  id=\"open_tools\">
				<a class=\"tooltip\" title=\"$tipprofile\">
					<img title=\"\" src=\"./icon/account.png\"/>
				</a>
			</div>";
			}
		?>
		<div class="addon_button" value="chat_panel"  id="open_chat">
			<a class="tooltip" title="<?php echo $tipchat; ?>">
				<img title="" src="./icon/chat.png"/>
			</a>
		</div>
		<?php if($user['guest'] < 1){
			echo "<div id=\"open_option\" value=\"option_tab\" class=\"load_option\">
					<img class=\"opt_open\" title=\"\" src=\"./icon/options.png\"/>
			</div>";
			}	
		?>
		<div class="logout_button">
			<a class="tooltip" title="<?php echo $tipquit; ?>">
				<img title="" src="./icon/logout.png"/>
			</a>
		</div>

	</div>
</div>