<div id="picker_box">

	<div class="pick_color" style="background:#5b0f01" value="#5b0f01"></div>
	<div class="pick_color" style="background:#a71b00" value="#a71b00"></div>
	<div class="pick_color" style="background:#cd4126" value="#cd4126"></div>
	<div class="pick_color" style="background:#dd7e6c" value="#dd7e6c"></div>
	<div class="pick_color" style="background:#990100" value="#990100"></div>

	
	<div class="pick_color" style="background:#670001" value="#670001"></div>
	<div class="pick_color" style="background:#d50006" value="#d50006"></div>
	<div class="pick_color" style="background:#e16668" value="#e16668"></div>
	<div class="pick_color" style="background:#e99a95" value="#e99a95"></div>
	<div class="pick_color" style="background:#fe0000" value="#fe0000"></div>

	
	
	<div class="pick_color" style="background:#7a3f05" value="#7a3f05"></div>
	<div class="pick_color" style="background:#e6903b" value="#e6903b"></div>
	<div class="pick_color" style="background:#f6b26b" value="#f6b26b"></div>
	<div class="pick_color" style="background:#facb9d" value="#facb9d"></div>
	<div class="pick_color" style="background:#fe9903" value="#fe9903"></div>

	
	<div class="pick_color" style="background:#7c5f00" value="#7c5f00"></div>
	<div class="pick_color" style="background:#f1bf38" value="#f1bf38"></div>
	<div class="pick_color" style="background:#fdda66" value="#fdda66"></div>
	<div class="pick_color" style="background:#ffe69b" value="#ffe69b"></div>
	<div class="pick_color" style="background:#ffff01" value="#ffff01"></div>	

	
	<div class="pick_color" style="background:#284e13" value="#284e13"></div>
	<div class="pick_color" style="background:#6aa950" value="#6aa950"></div>
	<div class="pick_color" style="background:#95c47e" value="#95c47e"></div>
	<div class="pick_color" style="background:#b7d7a8" value="#b7d7a8"></div>
	<div class="pick_color" style="background:#00ff01" value="#00ff01"></div>

	
	<div class="pick_color" style="background:#0d333e" value="#0d333e"></div>
	<div class="pick_color" style="background:#46808b" value="#46808b"></div>
	<div class="pick_color" style="background:#74a5b3" value="#74a5b3"></div>
	<div class="pick_color" style="background:#a3c4c9" value="#a3c4c9"></div>
	<div class="pick_color" style="background:#00ffff" value="#00ffff"></div>	

	
	
	<div class="pick_color" style="background:#083763" value="#083763"></div>
	<div class="pick_color" style="background:#3e84c2" value="#3e84c2"></div>
	<div class="pick_color" style="background:#70a7dd" value="#70a7dd"></div>
	<div class="pick_color" style="background:#9fc5e9" value="#9fc5e9"></div>
	<div class="pick_color" style="background:#0200f9" value="#0200f9"></div>

	
	<div class="pick_color" style="background:#20124d" value="#20124d"></div>
	<div class="pick_color" style="background:#664ea4" value="#664ea4"></div>
	<div class="pick_color" style="background:#907cc1" value="#907cc1"></div>
	<div class="pick_color" style="background:#b4a6d7" value="#b4a6d7"></div>
	<div class="pick_color" style="background:#9900fb" value="#9900fb"></div>	

	
	<div class="pick_color" style="background:#4c1131" value="#4c1131"></div>
	<div class="pick_color" style="background:#a44d77" value="#a44d77"></div>
	<div class="pick_color" style="background:#c37ba1" value="#c37ba1"></div>
	<div class="pick_color" style="background:#d7a6bc" value="#d7a6bc"></div>
	<div class="pick_color" style="background:#fc01fc" value="#fc01fc"></div>	

	
	<div class="pick_color" style="background:#000000" value="#000000"></div>
	<div class="pick_color" style="background:#434343" value="#434343"></div>
	<div class="pick_color" style="background:#666666" value="#666666"></div>
	<div class="pick_color" style="background:#ffffff" value="#ffffff"></div>
	<div class="empty_pick pick_color" value="none"></div>
</div>