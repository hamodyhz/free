<div  class="panels panelone" id="chat_panel">
	<div class="top_option bottom_separator">
		<div class="close_option">
			<img class="close_panel" value="chat_panel" src="./icon/close.png"/>
		</div>
		<div class="inner_top_option">
			<a class="tooltip2" title="<?php echo $tipuser; ?>">
				<img title="" id="chat_user" src="./icon/room.png"/>
			</a>
			<a class="tooltip2" title="<?php echo $tiprooms; ?>">
				<img title="" id="chat_room"  src="./icon/rooms.png"/>
			</a>
			<?php if($setting['allow_private'] == 1 && $user['user_access'] == 4){
					if($user['guest'] == 0 || $user['guest'] == 1 && $setting['guest_chat'] == 1){
						echo "<a class=\"tooltip2\" title=\"$tipprivate\"><img title=\"\" id=\"chat_private\"  src=\"./icon/private.png\"/></a>"; 
					}
				}
				if($user['user_access'] == 4 && $user['guest'] != 1){
					echo "<a class=\"tooltip2\" title=\"$tipfriends\">
						<img title=\"\" id=\"chat_friends\"  src=\"./icon/friends.png\"/>
						</a>";
				}
			?>
		</div>
	</div>
	<div class="panel_element top_separator">
		<div id="room_wrap">
		</div>
		<div id="user_wrap">
		</div>
	</div>
	<div class="clear_panel">
	</div>
</div>