<?php
				$action = date('m/d/Y H:i:s', $user['last_action']);
				
				if($user['user_age'] == 0){
					$my_age = $lang_hidden;
				}
				else {
					$my_age = $user['user_age'] . " years old";
				}
				if($user['user_sex'] == 0){
					$sex = $lang_hidden;
				}
				else{
					if($user['user_sex'] == 1){
						$sex = $lang_male;
					}
					elseif ($user['user_sex'] == 2){
						$sex = $lang_female;
					}
				}
				if($user['user_description'] == ''){
					$description = $user['user_name'] . " $lang_description";
				}
				elseif($user['user_description'] == 'you dont have set a description'){
					$description = $user['user_name'] . " $lang_description";
				}
				else{
					$description = $user['user_description'];
				}
				$my_gender = $user['user_sex'];
				$my_sound = $user['user_sound'];
?>
<div class="panels top_panels panelone"  id="tools_panel">
	<div class="top_option bottom_separator">
		<div class="close_option">
			<img class="close_panel" value="tools_panel" src="./icon/close.png"/>
		</div>
		<div class="inner_top_option">
		</div>
	</div>
	<div class="panel_element top_separator">
				<div id="avatar">
						<img class="profile_avatar" src="avatar/<?php echo $user['user_avatar']; ?>"/>
					</div>
					<div class="profile_info centered_element">
						<div class="details_first bottom_separator">
							<p class="change_avatar"><span class="sub_color"><?php echo $upchangeavatar; ?></span></p>
							<form id="myForm" action="system/file.php" method="post">
								<input type="file" name="file" id="file">
								<input class="sub_button hover_element" type="submit"  id="submit_avatar" value="<?php echo $submitavatar; ?>" /> 
							</form>
							<div class="panel_error"><p class="error"> </p></div>
						</div>
						<div class="details top_separator bottom_separator details_select">
							<div class="account_element_title">
								<p><span class="sub_color"><?php echo $lang_age; ?>:</span></p>
							</div>
							<div class="account_element_select">
								<select class="select_account" id="select_age">
									<?php
										for($value = 15; $value <= 99; $value++){
												if($value == $my_age){
													echo "<option value=\"$value\" selected=\"selected\">$value</option>";
												}
												else{
													echo "<option value=\"$value\">$value</option>";
												}
										}				
									?>	
									<option value="0" <?= $my_age == 0 ? 'selected="selected"' : '' ?>><?php echo $uphidden; ?></option>				
								</select>
							</div>
							<div class="clear"></div>
						</div>
						<div class="details top_separator bottom_separator details_select">
							<div class="account_element_title">
								<p><span class="sub_color"><?php echo $lang_sex; ?>:</span></p>
							</div>
							<div class="account_element_select">
								<select class="select_account" id="select_gender">
									<option value="0" <?= $my_gender == 0 ? 'selected="selected"' : '' ?>><?php echo $uphidden; ?></option>
									<option value="1" <?= $my_gender == 1 ? 'selected="selected"' : '' ?>><?php echo $lang_male; ?></option>
									<option value="2" <?= $my_gender == 2 ? 'selected="selected"' : '' ?>><?php echo $lang_female; ?></option>
								</select>
							</div>
							<div class="clear"></div>
						</div>
						<div class="details top_separator bottom_separator details_select">
							<div class="account_element_title">
								<p><span class="sub_color"><?php echo $upsound; ?>:</span></p>
							</div>
							<div class="account_element_select">
								<select class="select_account" id="select_sound">
									<option value="1" <?= $my_sound == 1 ? 'selected="selected"' : '' ?>><?php echo $sson; ?></option>
									<option value="0" <?= $my_sound == 0 ? 'selected="selected"' : '' ?>><?php echo $ssoff; ?></option>
								</select>
							</div>
							<div class="clear"></div>
						</div>
						<div class="details_last top_separator"><p><span class="sub_color"><?php echo $lang_email; ?>:</span> <?php echo $user['user_email']; ?></p></div>
					<div class="profile_description_wrap bottom_separator centered_element">
						<div class="profile_description_title bottom_separator bottom_separator">
							<p class="sub_color"><?php echo $lang_about; ?></p>
						</div>
						<div class="profile_description top_separator">
							<textarea class="background_box" id="my_description" placeholder="<?php echo $description; ?>" maxlength="500" value=""></textarea>
						</div>
						<button class="sub_button hover_element" id="account_button"><?php echo $upupdate; ?></button>
					</div>
					<div class="details change_password top_separator">
						<p class="change_avatar"><span class="sub_color"><?php echo $upchangepass; ?></span></p>
						<label><?php echo $upchangepass2; ?></label></br>
						<input class="input_password background_box" id="old_password" type="password"/></br>
						<label><?php echo $upchangepass3; ?></label></br>
						<input class="input_password background_box" id="new_password" type="password"/></br>
						<label><?php echo $upchangepass4; ?></label></br>
						<input class="input_password background_box" id="confirm_password" type="password"/></br>
						<button class="sub_button hover_element"  id="update_password"><?php echo $upchangepass5; ?></button><br/>
					</div>
				</div>
	</div>
	<div class="clear_panel">
	</div>
</div>