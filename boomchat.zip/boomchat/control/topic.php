<div id="wrap_topic">
	<div id="room_topic">
	</div>
</div>