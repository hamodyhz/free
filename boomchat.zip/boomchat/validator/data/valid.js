	
$(document).ready(function(){
	$(document).on('click', '#chat_button', function() {
		document.location.href = '../';
	});
	
});