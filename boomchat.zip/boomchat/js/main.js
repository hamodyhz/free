
$(document).ready(function(){
		
	// processing the moderator and admin option from user list ... 
	
	$('#chat_panel').on('click', '.panel_element .get_kick, .panel_element .get_ban, .panel_element .get_mute, .panel_element .get_unmute, .panel_element .get_kill, .panel_element .get_ignore, .panel_element .get_friends', function(){
		
		var optionTarget = $(this).attr('value');
		var optionEffect = $(this).attr('class');
		
		$.ajax({
			url: "system/option_process.php?target="+ optionTarget +"&option="+ optionEffect,
			cache: false,
			success: function(response)
			{
				if(response == 1){
					$('.option_list').slideUp(100);
					chat_reload();
					user_reload();
				}
				if(response == 103){
					$('.option_list').slideUp(100);
					$('#chat_error').html("<span class=\"error\">"+system.ing1+"</span>").hide().fadeIn(300).delay(3000).fadeOut();
				}
				if(response == 102){
					$('.option_list').slideUp(100);
					$('#chat_error').html("<span class=\"success\">"+system.ing2+"</span>").hide().fadeIn(300).delay(3000).fadeOut();
				}
				if(response == 104){
					$('.option_list').slideUp(100);
					$('#chat_error').html("<span class=\"error\">"+system.friend1+"</span>").hide().fadeIn(300).delay(3000).fadeOut();
				}
				if(response == 105){
					$('.option_list').slideUp(100);
					$('#chat_error').html("<span class=\"success\">"+system.friend2+"</span>").hide().fadeIn(300).delay(3000).fadeOut();
				}
			},
		});
		
	});
	
	
	// open user profile ...
	
	$('#chat_panel').on('click', '.panel_element .get_info', function(){
		
		$('.option_list').slideUp(300);
		var profileTarget = $(this).attr("value");
		var panelTarget = "profile_panel";
		var optionSize = $('#'+panelTarget).css('width');
		
		$('#'+panelTarget).animate({right:"+="+optionSize},400);
	
		$.ajax({
			url: "system/get_profile.php?profile_target="+ profileTarget,
			cache: false,
			success: function(response)
			{
					$("#profile_panel .panel_element").html(response);
			},
		});
		
	});
	
	
	$(document).on('click', '.other_panels', function(){
		
		var panelTarget = $(this).attr('value');
		var panelSize = $('#'+panelTarget).css('width');
		var panelContent = $(this).attr('id');
		var marginCheck = parseInt($('#'+panelTarget).css('right'));
		
		if(panelTarget == "addon_panel" && marginCheck >= 1){
			$.ajax({
				url: "addons/" + panelContent + "/" + panelContent + ".php",
				cache: false,
				success: function(response){
					$("#addon_panel .panel_element").html(response);
				},
			});
		}
		else {
			if (marginCheck >= 1) {
				$('#'+panelTarget).animate({right:"-="+panelSize},400);
			}
			else {
				$( ".top_panels" ).each(function() {
					var marginLook = parseInt($(this).css('right'));
					var otherPanels = $(this).css('width');
					if(marginLook >= 1){
						$(this).animate({right:"-="+otherPanels},400);
					}
				});
				$('#'+panelTarget).animate({right:"+="+panelSize},400);
					if (panelTarget == "history_panel"){
							historyReload();
					}
					if (panelTarget == "image_panel"){
							uploadReload();
					}
					if(panelTarget == "main_option"){
						admin_setting_reload();
					}
					if (panelTarget == "theme_panel"){
						themeReload();	
					}
					if(panelTarget == "ignore_panel"){
						showIgnore();
					}
					if(panelTarget == "addon_panel"){
						$.ajax({
							url: "addons/" + panelContent + "/" + panelContent + ".php",
							cache: false,
							success: function(response){
								$("#addon_panel .panel_element").html(response);
							},
						});
					}
			}
		
		}
		
		
	});
	
	// show and hide panels
	
	$(".addon_button").click(function(){
	
		var panelTarget = $(this).attr('value');
		var optionSize = $('#'+panelTarget).css('width');
		var marginCheck = parseInt($('#'+panelTarget).css('right'));
		
		if (marginCheck >= 1) {
			$('#'+panelTarget).animate({right:"-="+optionSize},400);
		}
		else {
			$( ".panels" ).each(function() {
				var marginLook = parseInt($(this).css('right'));
				var otherPanels = $(this).css('width');
				if(marginLook >= 1){
					$(this).animate({right:"-="+otherPanels},400);
				}
			});
			$('#'+panelTarget).animate({right:"+="+optionSize},400);
			
			if (panelTarget == "chat_panel"){
				dataControl = "1";
				user_reload();	
			}
		}
		
	});
	
	// close options panels ...
	
	$(".close_panel").click(function(){
	
		var panelTarget = $(this).attr('value');
		var optionSize = $('#'+panelTarget).css('width');
		var marginCheck = parseInt($('#'+panelTarget).css('right'));
		
		if (marginCheck >= 1) {
			$('#'+panelTarget).animate({right:"-="+optionSize},400);
			
			if (panelTarget == "chat_panel"){
				dataControl = "0";	
			}
			if(panelTarget == "profile_panel"){
				$("#profile_panel .panel_element").html("");
			}
			if(panelTarget == "history_panel"){
				$("#history_container").html("");
			}
		}
		
	});
	
	// close private window 
	
	$(".close_private").click(function(){
	
		var panelTarget = $(this).attr('value');
		var optionSize = $('#'+panelTarget).css('height');
		var marginCheck = parseInt($('#'+panelTarget).css('bottom'));
		
		if (marginCheck >= 0) {
			$('#'+panelTarget).animate({bottom:"-="+optionSize},200);
			privateControl = "0";
		}
		
	});
	
	$("#image_panel").on('click', '.remove_image', function() {
		var imgTarget = $(this).attr('value');
			$.post('system/image_delete.php', {del_image: imgTarget}, function(response) {	
				if(response == 1){
					uploadReload();
				}
			});
	});
	
	$("#chat_panel").on('click', '.clear_private', function() {
		var Target = $(this).attr('value');
			$.post('system/private_clear.php', {target: Target}, function(response) {	
				if(response == 1){
					privateOpen();
				}
			});
	});
	
	// log out user from the chat on click
	
	$(".logout_button").click(function(){
		logOut();
	});
	
	$("#chat_room").click(function(){
		dataControl = "2";
		showRooms();
	});
	$("#chat_user").click(function(){
		dataControl = "1";
		user_reload();
	});
	$("#chat_friends").click(function(){
		dataControl = "5";
		reloadFriends();
	});
	$("#chat_private").click(function(){
		dataControl = "4";
		privateOpen();
	});
	$("#my_history").click(function(){
		userHistory();
	});
	$("#chat_history").click(function(){
		historyReload();
	});
	
	// update user information when clicking on update account button 
	
	$('#tools_panel').on('click', '#account_button', function() {
		var set_age = $( "#select_age option:selected" ).val();
		var set_gender = $( "#select_gender option:selected" ).val();
		var set_description = $( "#my_description" ).val();
		var set_sound = $( "#select_sound option:selected" ).val();
		$.post('system/account_data.php', {
		
		set_age: set_age,
		set_gender: set_gender,
		set_description: set_description,
		set_sound: set_sound
		
		}, function(response) {
			if(response == 1){
				$("#account_button").html("<span class=\"success\">"+system.updateSuccess+"</span>").delay(3000).queue(function(n) {$(this).html(system.updateInfo);
					n();
				});
			}
			else {
				$("#account_button").html("<span class=\"error_message\">"+system.errorOccur+"</span>").delay(3000).queue(function(n) {$(this).html(system.updateInfo);
					n();
				});				
			}
		});
		return false;
		
	});
	
	// change user password 

	$('#tools_panel').on('click', '#update_password', function() {
		var old_password = $( "#old_password" ).val();
		var new_password = $( "#new_password" ).val();
		var confirm_password = $( "#confirm_password" ).val();
		$.post('pass_change.php', {
		
		old_password: old_password,
		new_password: new_password,
		confirm_password: confirm_password
		
		}, function(response) {
			if(response == 6){
				$( "#new_password" ).val("");
				$( "#confirm_password" ).val("");
				$("#update_password").html("<span class=\"error_message\">"+system.pass5+"</span>").delay(3000).queue(function(n) {$(this).html("Update infos");
					n();
				});			
			}
			else if (response == 5){
				$( "#old_password" ).val("");
				$( "#confirm_password" ).val("");
				$( "#new_password" ).val("");
				$("#update_password").html("<span class=\"error_message\">"+system.errorOccur+"</span>").delay(3000).queue(function(n) {$(this).html("Update infos");
					n();
				});				
			}
			else if (response == 4){
				$( "#new_password" ).val("");
				$( "#confirm_password" ).val("");
				$("#update_password").html("<span class=\"error_message\">"+system.pass4+"</span>").delay(3000).queue(function(n) {$(this).html("Update infos");
					n();
				});				
			}
			else if (response == 3){
				$("#update_password").html("<span class=\"error_message\">"+system.pass3+"</span>").delay(3000).queue(function(n) {$(this).html("Update infos");
					n();
				});				
			}
			else if (response == 2){
				$( "#old_password" ).val("");
				$("#update_password").html("<span class=\"error_message\">"+system.pass2+"</span>").delay(3000).queue(function(n) {$(this).html("Update infos");
					n();
				});				
			}
			else if (response == 1){
				$( "#confirm_password" ).val("");
				$( "#old_password" ).val("");
				$( "#new_password" ).val("");
				$("#update_password").html("<span class=\"success\">"+system.updateSuccess+"</span>").delay(3000).queue(function(n) {$(this).html("Update infos");
					n();
				});				
			}
			else {
				return false;
			}
		});
		return false;
		
	});
	
	
	
	// allow to change the chat theme 
	$('#theme_panel').on('click', '.panel_element .theme_button', function() {
		var theme = $(this).attr('value');
			$.post('system/theme_manager.php', {theme: theme}, function(response) {
				themeReload();
				$('#active_theme').attr('href',"css/themes/"+ theme +".css");	
			});
		return false;
	});
	
	
	// bring the user in selected room and update userlist, chat log
	$(document).on('click', '#chat_panel .roombutton', function() {
		var target = $(this).attr('id');
		var roomtarget = $(this).attr('value');
		$('.roombutton').removeClass('hoverroom');
		$(this).addClass('hoverroom');
		
		$.post('system/room_target.php', { room_target: target }, function(response) {
			if (response == 1){
				$('#chat_error').html("<span class=\"error\">"+system.inRoom+"</span>").hide().fadeIn(300).delay(3000).fadeOut();
				return false;
			}
			if(response == 2){
				$('#chat_error').html("<span class=\"error\">"+system.roomLock+"</span>").hide().fadeIn(300).delay(3000).fadeOut();
				return false;
			}
			else {
				dataControl = 1;
				$('#user_room').val(roomtarget);
				$('#content').focus();
				$("#show_chat ul").html("");
				user_room = roomtarget;
				chat_reload();
				topic_reload();
				user_reload();
				checkScroll = 0;
				scrollCompare = 0;
			}
		});
		return false;
	});
		
	// delete a specific log in the chat
	
	$(document).on('click', '#show_chat .delete_log', function() {
		var del_post = $(this).attr('value');
			$.post('system/delete_post.php', {del_post: del_post}, function(response) {	
				chat_reload();			
			});
	});
	
	// ignored from ignore list
	
	$(document).on('click', '#ignore_panel .delete_ignore button', function() {
	
		var delete_ignore = $(this).val();
		
		$.post('system/remove_ignore.php', { delete_ignore: delete_ignore }, function(response) {
			showIgnore();
		});		
		return false;
	});
	
	// delete friend from friends list
	
	$(document).on('click', '#chat_panel .delete_friend button', function() {
	
		var delete_friend = $(this).val();
		
		$.post('system/remove_friend.php', { delete_friend: delete_friend }, function(response) {
			reloadFriends();
		});		
		return false;
	});
	
	// upload avatar to server
		$('#myForm').ajaxForm(function(response) {
			if(response == 1){
				$('.panel_error p').text(system.upload1).show();
			}
			else if(response == 2){
				$('.panel_error p').text(system.upload2).show();

			}
			else if(response == 3){
				$('.panel_error p').text(system.upload1).show();

			}
			else if(response == 4){
				$('.panel_error p').text(system.upload3).show();

			}
			else if(response > 5){
				$('.panel_error p').text(system.upload4+" "+response+' kb').show();

			}
			else if (response == 5){
					reload_avatar();
			}
			else{
				return false;
			}
		});
		
	// upload avatar to server
		$('#formupload').ajaxForm(function(response) {
			if(response == 1){
				$('#warnupload p').text(system.upload3).show();
			}
			else if(response == 2){
				$('#warnupload p').text(system.upload6).show();

			}
			else if(response == 3){
				$('#warnupload p').text(system.upload7).show();

			}
			else if (response == 4){
				$('#warnupload p').text(system.upload8).show();
			}
			else if (response == 5){
				uploadReload();
				var uploadInput = $('#file_image');
				uploadInput.replaceWith(uploadInput.val('').clone(true));
			}
			else{
			}
		});
		
	$( window ).resize(function() {
		panelMargin();
		adsMargin();
		adjustHeight();
		checkScroll = 0;
		scrollCompare = 0;
		$("#picker_box").hide();
		$('#list_emoticon').hide();
	});
	
});

function openUsermanual(){
	window.open("documentation/manual.php","_blank","toolbar=no, scrollbars=yes, resizable=no, top=100, left=100, width=800, height=600");
};