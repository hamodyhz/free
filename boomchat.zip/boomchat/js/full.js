$(document).ready(function(){

	// open private window  
	
	$(document).on('click', '.panel_element .send_private, .private_view, .chat_avatar_wrap, .friend_private', function(){
		
		$('.option_list').slideUp(300);
		var profileTarget = $(this).attr("value");
		var panelTarget = "private_panel";
		var optionSize = $('#'+panelTarget).css('height');
		var marginCheck = parseInt($('#'+panelTarget).css('bottom'));
		
		if (marginCheck < 1) {
			privateControl = "1";
			$('#'+panelTarget).animate({bottom:"+="+optionSize},200);
			$('#show_private').html("");
			$('.private_target').html(profileTarget);
			$('.add_friend_button').attr('value',profileTarget);
			$('#private_content').attr('name', profileTarget);
			privateReload();
		}
		else{
			privateControl = "1";
			$('#show_private').html("");
			$('.private_target').html(profileTarget);
			$('.add_friend_button').attr('value',profileTarget);
			$('#private_content').attr('name', profileTarget);
			privateReload();
		}
		
	});
	
	// add a friend to friend list on button click
	
	$("#private_panel").on('click', '.add_friend_button', function() {
		var target = $(this).attr('value');
			$.post('system/add_friend.php', {friend: target}, function(response) {	
				if(response == 2){
					$('#chat_error').html("<span class=\"error\">"+system.type2+"</span>").hide().fadeIn(300).delay(5000).fadeOut();
				}
				else if(response == 3){
					$('#chat_error').html("<span class=\"error\">"+system.type3+"</span>").hide().fadeIn(300).delay(5000).fadeOut();			
				}
				else if(response == 203){
					$('#chat_error').html("<span class=\"error\">"+system.friend1+"</span>").hide().fadeIn(300).delay(3000).fadeOut();
				}
				else if(response == 204){
					$('#chat_error').html("<span class=\"success\">"+system.friend2+"</span>").hide().fadeIn(300).delay(3000).fadeOut();
				}
				else {
					return false;
				}
			});
	});
	
	// open user options in user list
	
	$('#chat_panel').on('click', '.panel_element .users_option .open_user', function() {
		if($(this).next('.option_list').css('display') == 'none'){
				$('.option_list').slideUp(300);
				$(this).next().slideDown(300);
		}
		else {
			$(this).next('.option_list').slideUp(300);
		}
	});

	// paste link of image when clicking on scisor icon 
	
	$("#image_panel").on('click', '.copy_link', function(){
		var commandInput = $(this).attr('value');
		emoticon($('#content')[0], commandInput + " ");
		var optionSize = $('#image_panel').css('width');
		$('#image_panel').animate({right:"-="+optionSize},400);
	});
	
	// Paste 'user' in main input when username is clicked in main chat window
	
	$('#container_show_chat').on('click', '#show_chat .username', function() {
        emoticon($('#content')[0], $(this).text() + '');
   });
   
	// Paste reply to input box when reply is clicked
	
	$('#container_show_chat').on('click', '#show_chat .private_reply', function() {
			var private_target = $(this).attr('value');
			$('#content').val('').focus();
        emoticon($('#content')[0], "/msg"+' '+private_target + ' ');
   });
	
	// paste command to main input
	
	$(document).on('click', '#help_panel .wrap_command', function(){
		var commandInput = $(this).attr('value');
		var commandPaste = commandInput;
		var optionSize = $('#main_option').css('width');
		$('#help_panel').animate({right:"-="+optionSize},400);
		$('#content').val('').focus().val(commandPaste+' ');
		
	});
	
	
	// send a private message 
	
	$('#private_input').submit(function(event){
		var target = $('#private_content').attr('name');
		var message = $('#private_content').val();
		if(message == ''){
			event.preventDefault();
		}
		else if (/^\s+$/.test($('#content').val())){
			event.preventDefault();
			$('#private_content').val('');
			$('#private_content').focus();
		}
		else{
			$.post('system/private_process.php', {target: target, message: message}, function(response) {
				$('#private_content').val('');
				$('#private_content').focus();
				privateReload();
			});
		}
		return false;
	});
	
	
	// Send a global message or a private message in the main chat window
	var waitReply = 0;
	$('#main_input').submit(function(event){
		var message = $('#content').val();
		var bold = $('#bold_item').attr('value');
		var italic = $('#italic_item').attr('value');
		var underline = $('#underline_item').attr('value');
		var high = $('#high_pick').css('backgroundColor');
		var color = $('#text_pick').css('backgroundColor');
		if(emOn != 1){
			high = 'transparent';
			color = 'transparent';
			bold = '0';
			italic = '0';
			underline = '0';
		}
		
		if(message == ''){
			event.preventDefault();
		}
		else if (/^\s+$/.test($('#content').val())){
			event.preventDefault();
			$('#content').val('').focus();
		}
		else{
			$('#content').val('').focus();
			if(waitReply == 0){
				waitReply = 1;
				$.post('system/chat_process.php', {content: message, bold: bold, italic: italic, underline: underline, high: high, color: color}, function(response) {
					if (response == 1){
						$('#chat_error').html("<span class=\"error\">"+ system.type1 +"</span>").hide().fadeIn(100).delay(5000).fadeOut();
					}
					else if (response == 2){
						$('#chat_error').html("<span class=\"error\">"+system.type2+"</span>").hide().fadeIn(300).delay(5000).fadeOut();				}
					else if (response == 3){
						$('#chat_error').html("<span class=\"error\">"+system.type3+"</span>").hide().fadeIn(300).delay(5000).fadeOut();					
					}
					else if (response == 4){					
					}
					else if (response == 5){
						$('#chat_error').html("<span class=\"error\">"+system.type4+"</span>").hide().fadeIn(300).delay(3000).fadeOut();					
					}
					else if (response == 6){
						$('#chat_error').html("<span class=\"error\">"+system.type5+"</span>").hide().fadeIn(300).delay(3000).fadeOut();					
					}
					else if (response == 7){
						$('#chat_error').html("<span class=\"success\">"+system.type6+"</span>").hide().fadeIn(300).delay(3000).fadeOut();					
					}
					else if (response == 8){
						$('#chat_error').html("<span class=\"error\">"+system.type7+"</span>").hide().fadeIn(300).delay(3000).fadeOut();					
					}
					else if (response == 9){
						$('#chat_error').html("<span class=\"error\">"+system.type8+"</span>").hide().fadeIn(300).delay(3000).fadeOut();					
					}
					else if (response == 10){
						$('#chat_error').html("<span class=\"error\">"+system.type9+"</span>").hide().fadeIn(300).delay(3000).fadeOut();					
					}
					else if (response == 11){
						topic_reload();
					}
					else if (response == 12){
						$('#chat_error').html("<span class=\"error\">"+system.type10+"</span>").hide().fadeIn(300).delay(3000).fadeOut();					
					}
					else if (response == 13){
						$('#chat_error').html("<span class=\"error\">"+system.type11+"</span>").hide().fadeIn(300).delay(5000).fadeOut();					
					}
					else if (response == 14){
						$('#chat_error').html("<span class=\"error\">"+system.type12+"</span>").hide().fadeIn(300).delay(5000).fadeOut();					
					}
					else if (response == 15){
						$('#chat_error').html("<span class=\"success\">"+system.type13+"</span>").hide().fadeIn(300).delay(3000).fadeOut();					
					}
					else if (response == 16){
						$('#chat_error').html("<span class=\"error\">"+system.type14+"</span>").hide().fadeIn(300).delay(3000).fadeOut();					
					}		
					else if (response == 17){
						$('#chat_error').html("<span class=\"error\">"+system.type17+"</span>").hide().fadeIn(300).delay(3000).fadeOut();					
					}
					else if (response == 18){
						$('#chat_error').html("<span class=\"success\">"+system.type18+"</span>").hide().fadeIn(300).delay(3000).fadeOut();	
					}
					else if (response == 19){
						$('#chat_error').html("<span class=\"error\">"+system.type19+"</span>").hide().fadeIn(300).delay(3000).fadeOut();					
					}
					else if (response == 20){
						$('#chat_error').html("<span class=\"success\">"+system.type20+"</span>").hide().fadeIn(300).delay(3000).fadeOut();	
					}
					else if (response == 21){
						$('#chat_error').html("<span class=\"error\">"+system.type21+"</span>").hide().fadeIn(300).delay(3000).fadeOut();					
					}
					else if (response == 22){
						$('#chat_error').html("<span class=\"error\">"+system.type22+"</span>").hide().fadeIn(300).delay(3000).fadeOut();					
					}
					else if (response == 23){
						$('#chat_error').html("<span class=\"success\">"+system.type23+"</span>").hide().fadeIn(300).delay(3000).fadeOut();	
					}
					else if (response == 24){
						$('#chat_error').html("<span class=\"success\">"+system.type24+"</span>").hide().fadeIn(300).delay(3000).fadeOut();	
					}
					else if (response == 25){
						$('#chat_error').html("<span class=\"error\">"+system.type25+"</span>").hide().fadeIn(300).delay(3000).fadeOut();					
					}
					else if (response == 26){
						$('#chat_error').html("<span class=\"error\">"+system.type26+"</span>").hide().fadeIn(300).delay(3000).fadeOut();					
					}
					else if (response == 27){
						$('#chat_error').html("<span class=\"error\">"+system.type27+"</span>").hide().fadeIn(300).delay(3000).fadeOut();					
					}
					else if (response == 28){
						$('#chat_error').html("<span class=\"success\">"+system.type28+"</span>").hide().fadeIn(300).delay(3000).fadeOut();	
					}
					else if (response == 99){
						openUsermanual();
					}
					else if (response == 200){
						$('#chat_error').html("<span class=\"error\">"+system.ing1+"</span>").hide().fadeIn(300).delay(3000).fadeOut();
					}
					else if (response == 201){
						$('#chat_error').html("<span class=\"success\">"+system.ing2+"</span>").hide().fadeIn(300).delay(3000).fadeOut();	
					}
					else if (response == 202){
						$('#chat_error').html("<span class=\"error\">"+system.type15+"</span>").hide().fadeIn(300).delay(3000).fadeOut();
					}
					else if (response == 203){
						$('#chat_error').html("<span class=\"error\">"+system.friend1+"</span>").hide().fadeIn(300).delay(3000).fadeOut();
					}
					else if (response == 204){
						$('#chat_error').html("<span class=\"success\">"+system.friend2+"</span>").hide().fadeIn(300).delay(3000).fadeOut();	
					}
					else{
					$('#name').val('');
					chat_reload();
					}
					waitReply = 0;
				});
			}
			else {
				event.preventDefault();
			}
		}
		return false;
	});
	
});