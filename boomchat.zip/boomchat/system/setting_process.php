<?php 
/////////// BoomChat v 1.00 /////////////////
// all right reserved to Robert Barnab�
////////////////////////////////////////////
require_once("config.php");
	// update setting based on admin setting value
	$data_delay = $setting['data_delete'];
	if(isset($_POST['site_title'])
		&& isset($_POST['site_domain'])
		&& isset($_POST['set_registration'])
		&& isset($_POST['set_maintenance'])
		&& isset($_POST['set_flood'])
		&& isset($_POST['set_unmute'])
		&& isset($_POST['set_default_theme'])
		&& isset($_POST['set_allow_theme'])
		&& isset($_POST['set_log_history'])
		&& isset($_POST['set_chat_history'])
		&& isset($_POST['set_data_delete'])
		&& isset($_POST['set_max_message'])
		&& isset($_POST['set_max_username'])
		&& isset($_POST['set_max_avatar'])
		&& isset($_POST['set_allow_link'])
		&& isset($_POST['set_away']) 
		&& isset($_POST['set_gone']) 
		&& isset($_POST['set_max_hosting'])
		&& isset($_POST['set_emoticon'])
		&& isset($_POST['set_private'])
		&& isset($_POST['set_allow_history'])
		&& isset($_POST['set_upload'])
		&& isset($_POST['set_max_weight'])
		&& isset($_POST['set_ads'])
		&& isset($_POST['set_adsdelay'])
		&& isset($_POST['set_adscount'])
		&& isset($_POST['set_orientation'])
		&& isset($_POST['set_welcome'])
		&& isset($_POST['set_guest'])
		&& isset($_POST['set_guest_chat'])
		&& isset($_POST['set_guest_clear'])
		&& isset($_POST['set_validation'])
		&& isset($_POST['set_cookie'])
		&& isset($_POST['set_email_repeat'])
		&& isset($_POST['set_speed'])
		&& isset($_POST['set_language'])
		&& isset($_POST['set_show_topic'])
		&& $user['user_rank'] > 4 && $user['user_access'] == 4)
		
		{		
		$title = $mysqli->real_escape_string(trim($_POST['site_title']));
		$domain = $mysqli->real_escape_string(trim($_POST['site_domain']));
		$registration = $mysqli->real_escape_string(trim($_POST['set_registration']));
		$maintenance = $mysqli->real_escape_string(trim($_POST['set_maintenance']));
		$flood = $mysqli->real_escape_string(trim($_POST['set_flood']));
		$unmute = $mysqli->real_escape_string(trim($_POST['set_unmute']));
		$theme = $mysqli->real_escape_string(trim($_POST['set_default_theme']));
		$allow_theme = $mysqli->real_escape_string(trim($_POST['set_allow_theme']));
		$chat_log = $mysqli->real_escape_string(trim($_POST['set_chat_history']));
		$history_log = $mysqli->real_escape_string(trim($_POST['set_log_history']));
		$data_delete = $mysqli->real_escape_string(trim($_POST['set_data_delete']));
		$max_message = $mysqli->real_escape_string(trim($_POST['set_max_message']));
		$max_username = $mysqli->real_escape_string(trim($_POST['set_max_username']));
		$max_avatar = $mysqli->real_escape_string(trim($_POST['set_max_avatar']));
		$link = $mysqli->real_escape_string(trim($_POST['set_allow_link']));
		$away = $mysqli->real_escape_string(trim($_POST['set_away']));
		$gone = $mysqli->real_escape_string(trim($_POST['set_gone']));
		$max_hosting = $mysqli->real_escape_string(trim($_POST['set_max_hosting']));
		$emoticon = $mysqli->real_escape_string(trim($_POST['set_emoticon']));
		$private = $mysqli->real_escape_string(trim($_POST['set_private']));
		$history = $mysqli->real_escape_string(trim($_POST['set_allow_history']));
		$upload = $mysqli->real_escape_string(trim($_POST['set_upload']));
		$max_weight = $mysqli->real_escape_string(trim($_POST['set_max_weight']));
		$adson = $mysqli->real_escape_string(trim($_POST['set_ads']));
		$adsdelay = $mysqli->real_escape_string(trim($_POST['set_adsdelay']));
		$adscount = $mysqli->real_escape_string(trim($_POST['set_adscount']));
		$orientation = $mysqli->real_escape_string(trim($_POST['set_orientation']));
		$welcome = $mysqli->real_escape_string(trim($_POST['set_welcome']));
		$guest = $mysqli->real_escape_string(trim($_POST['set_guest']));
		$guest_chat = $mysqli->real_escape_string(trim($_POST['set_guest_chat']));
		$guest_clear = $mysqli->real_escape_string(trim($_POST['set_guest_clear']));
		$validation = $mysqli->real_escape_string(trim($_POST['set_validation']));
		$cookie_ban = $mysqli->real_escape_string(trim($_POST['set_cookie']));
		$email_repeat = $mysqli->real_escape_string(trim($_POST['set_email_repeat']));
		$speed = $mysqli->real_escape_string(trim($_POST['set_speed']));
		$this_lang = $mysqli->real_escape_string(trim($_POST['set_language']));
		$display_topic= $mysqli->real_escape_string(trim($_POST['set_show_topic']));
		$guest_count = $setting['guest'];
		
		if($adscount == 1){
			$adsoff = 0;
		}
		else {
			$adsoff = 1;
		}
		if($guest == 0){
			$mysqli->query("DELETE FROM `users` WHERE `guest` = '1'");
			$guest_count = 1;
		}
		
		if($title == ''){$title = $setting['title'];}
		if($domain == ''){$domain = $setting['domain'];}
		$mysqli->query("UPDATE `setting` SET `title` = '$title', `language` = '$this_lang', `domain` = '$domain', `registration` = '$registration', `maintenance` = '$maintenance',
						`flood_delay` = '$flood', `mute_delay` = '$unmute', `default_theme` = '$theme', `max_message` = '$max_message', `max_username` = '$max_username', `file_weight` = '$max_weight',
						`allow_theme` = '$allow_theme', `chat_history` = '$chat_log', `log_history` = '$history_log', `data_delete` = '$data_delete', `max_avatar` = '$max_avatar', 
						`away` = '$away', `gone` = '$gone', `max_host` = '$max_hosting', `allow_link` = '$link',`allow_private` = '$private', `emoticon` = '$emoticon', 
						`allow_history` = '$history', `allow_image` = '$upload', `allow_ads` = '$adson', `ads_delay` = '$adsdelay', `ads_count` = '$adscount', `ads_stop` = '$adsoff',
						`orientation` = '$orientation', `welcome` = '$welcome', `allow_guest` = '$guest', `guest_chat` = '$guest_chat', `guest` = '$guest_count', `guest_clear` = '$guest_clear', 
						`activation` = '$validation', `cookie_ban` = '$cookie_ban', `allow_email` = '$email_repeat', `chat_speed` = '$speed', `show_topic` = '$display_topic'  WHERE `id` = 1");
		
			if($orientation !== $setting['orientation']){
				echo 3;
			}
		
		}
	else{
		echo 2;
	}
		
?>