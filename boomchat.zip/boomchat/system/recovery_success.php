<?php
require_once("config.php"); 

echo "<div id=\"login_error\"><div class=\"success recover_ok\" id=\"login_error_inside\">$recovery_success</div></div>
<form class=\"login_form\" autocomplete=\"off\">
	<div class=\"sub_button hover_element\" id=\"back_login\"><p>$back_login</p></div>
</form>";

?>