<?php	require_once("config_min.php");
?>

<?php 
	if ($user["user_access"] == 4){
	$me = $user['user_name'];
	
	$mysqli->query("UPDATE `private` SET `view` = 1 WHERE `target` = '$me'");
		echo 1;
	}
	else {
		die();
	}

?>