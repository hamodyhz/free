<?php require_once("config.php"); 
	if($user['upload_access'] != 1){ die(); }
?>
<?php
$uppath = $user["user_name"];
$picturepath = "../upload/$uppath/";
define('IMAGEPATH', $picturepath);
$ratio = $user["upload_count"];
$messageerreur = "";
$max = $setting['file_weight'];

if (isset($_FILES["file"])){
$allowedExts = array("gif", "jpeg", "jpg", "png", "JPG");
$temp = explode(".", $_FILES["file"]["name"]);
$extension = end($temp);
$size = round((($_FILES["file"]["size"] / 1024) / 1024), 2);

if ((($_FILES["file"]["type"] == "image/gif")
|| ($_FILES["file"]["type"] == "image/jpeg")
|| ($_FILES["file"]["type"] == "image/jpg")
|| ($_FILES["file"]["type"] == "image/pjpeg")
|| ($_FILES["file"]["type"] == "image/x-png")
|| ($_FILES["file"]["type"] == "image/png"))
|| ($_FILES["file"]["type"] == "image/JPG")
&& in_array($extension, $allowedExts))
  {
	if ($_FILES["file"]["error"] > 0)
	{
				echo 6;
	}
	else
	{
		if (file_exists("../upload/$uppath/" . str_replace(str_split('\\/:*?"<>_$-@&%|'), '' , preg_replace('/\s+/', '', $_FILES["file"]["name"]))))
								  {
								  echo 4; 
								  }
								  
		else if ($ratio >= $setting['max_host']){
								echo 3;
		
		
		}
		else if ((($_FILES["file"]["size"] / 1024)/1024) > $max){
		
							echo 2;
		
		}
								else
								  {
								  move_uploaded_file(preg_replace('/\s+/', '', $_FILES["file"]["tmp_name"]),
								  "../upload/$uppath/" . str_replace(str_split('\\/:*?"<>_$-@&%|'), '' , preg_replace('/\s+/', '', $_FILES["file"]["name"])));
								  $mysqli->query("UPDATE `users` SET `upload_count` = `upload_count` + 1 WHERE `user_name` = '{$user["user_name"]}'");
								  echo 5;
								  
		}
}
}
else
  {
		echo 1;
  }
}






?> 