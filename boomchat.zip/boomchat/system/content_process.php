<?php


	// list all addons in the addons section
	
	function listAddons(){
		$directory = "addons/";
		$files = glob($directory . "*");
		foreach($files as $file)
		{
		 if(is_dir($file))
			{
				$addons = str_replace($directory,'',$file);
				echo "<div  id=\"$addons\" value=\"addon_panel\" class=\"addon_options other_panels\">
						<img  value=\"" . str_replace("_"," ",$addons) . "\"src=\"addons/$addons/images/$addons.png\"/>
				</div>";
			}
		}
	}
	
	
	// list emoticon in the chat 
	
	function listSmilies()
	{
		if ($dir = opendir('emoticon')) 
		{
			while (false !== ($file = readdir($dir))) 
			{
				if ($file != "." && $file != "..")
				{
					$smile = preg_replace('/\.[^.]*$/', '', $file);
					echo "<div  class=\"emoticon closesmilies\"><img  src='emoticon/{$smile}.gif' title=':{$smile}:' onclick=\"emoticon(document.chat_data.content, ':{$smile}:')\" class=\"chat_emoticon\"'></div>\n";
				}
			}

			closedir($dir);
		}
	}
	// function to convert user typing to smilies
	function emoticon($emoticon)
	{
		if ($dir = opendir('../emoticon')) 
		{
			while (false !== ($file = readdir($dir)))
			{
				if ($file != "." && $file != "..")
				{
						$select = preg_replace('/\.[^.]*$/', '', $file);
						$emoticon = str_replace(':' . $select . ':', '<img  class="emo_chat" src="emoticon/' . $select . '.gif" title=":' . $select . ':"  > ', $emoticon);
				}
			}
			
			closedir($dir);
		}
		
		return $emoticon;
	}
	// link, youtube, and picture management regex
	function topiclink($source){

	$text = preg_replace('/(^|[^"])(((f|ht){1}tp:\/\/)[-a-zA-Z0-9@:%_\+.~#?&\/\/=]+)/i', '\\1<a href="\\2" target="_blank">\\2</a>', $source);
	return $text;
	}

	function linking($source) {
	  $render = preg_replace('@https?:\/\/([-\w\.]+[-\w])+(:\d+)?\/[\w\/_~\%\+\.-]+\.(png|gif|jpg|jpeg)((\?\S+)?[^\.\s])?@i', ' <a href="$0" class="fancybox"><img src="icon/photolink.gif"/></a> ', $source);
	  if(preg_last_error()) {
		$render = $source;
	  }
	  $render = preg_replace('@https?:\/\/(www\.)?youtube.com/watch\?v=[\w_-]*@i', ' <a href="$0" class="fancybox-video"><img src="icon/youtube.gif"/></a> ', $render);
	  $render = preg_replace('@([^=][^"])(https?://([-\w\.]+[-\w])+(:\d+)?(/([\w/_\.\%\+#-]*(\?\S+)?[^\.\s])?)?)@', '$1<a href="$2" target="_blank">$2</a>', $render);
	  return preg_replace('@^(https?://([-\w\.]+[-\w])+(:\d+)?(/([\w/_\.~\%\+#-]*(\?\S+)?[^\.\s])?)?)@', '<a href="$1" target="_blank">$1</a>', $render);
	}
	
	
	function excluded($n_exclude, $c_entry) 
	{
		foreach ($n_exclude as $u_exclude) {
			if (stripos(strtolower($c_entry),strtolower($u_exclude)) !== FALSE) {
				return true;
			}
		}
	}
	
function createThumbnail($pathToImage, $thumbWidth = 80) {
    $result = 1;
    if (is_file($pathToImage)) {
        $info = pathinfo($pathToImage);

        $extension = strtolower($info['extension']);
        if (in_array($extension, array('jpg', 'jpeg', 'png', 'gif'))) {

            switch ($extension) {
                case 'jpg':
                    $img = imagecreatefromjpeg("{$pathToImage}");
                    break;
                case 'jpeg':
                    $img = imagecreatefromjpeg("{$pathToImage}");
                    break;
                case 'png':
                    $img = imagecreatefrompng("{$pathToImage}");
                    break;
                case 'gif':
                    $img = imagecreatefromgif("{$pathToImage}");
                    break;
                default:
                    $img = imagecreatefromjpeg("{$pathToImage}");
            }
            // load image and get image size

            $width = imagesx($img);
            $height = imagesy($img);

            // calculate thumbnail size
            $new_width = $thumbWidth;
            $new_height = 80;

            // create a new temporary image
            $tmp_img = imagecreatetruecolor($new_width, $new_height);

            // copy and resize old image into new image
            imagecopyresized($tmp_img, $img, 0, 0, 0, 0, $new_width, $new_height, $width, $height);
                $pathToImage = str_replace(array('.jpg','.JPG','.jpeg','.png','.gif'),"",$pathToImage) . '_tumb.' . $extension;
            // save thumbnail into a file
            imagejpeg($tmp_img, "{$pathToImage}");
            $result = 0;
        } else {
            $result = 1;
        }
    } else {
        $result = 1;
    }
    return $result;
}

// converting text with users text tools selection

function styling($high, $bold, $italic, $color, $underline, $source) {
	
	$rbold = "";
	$runder = "";
	$ritalic = "";
	$rcolor = "";
	$rhigh = "";
	if($bold == 1){
		$rbold = " font-weight:bold;";
	}
	if($underline == 1){
		$runder = " text-decoration:underline;";
	}
	if($italic == 1){
		$ritalic = " font-style:italic;";
	}
	if($color != 'transparent' && $color != "rgba(0, 0, 0, 0)"){
		$rcolor = " color:$color;";
	}
	if($high != 'transparent' && $high != "rgba(0, 0, 0, 0)"){
		$rhigh = " background:$high; padding:1px 4px;";
	}
	$new_content = "<span style=\"$rbold$runder$ritalic$rcolor$rhigh\">$source</span>";
	
    return $new_content;
}

?>
