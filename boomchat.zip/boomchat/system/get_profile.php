<?php
/////////// BoomChat v 1.00 /////////////////
// all right reserved to Robert Barnab�
////////////////////////////////////////////	
require_once("config_min.php"); 


// get user profile
if(isset($_GET['profile_target']) && $user['user_access'] = 4){

	$target_name = $mysqli->real_escape_string(trim($_GET['profile_target']));
	$findtarget = $mysqli->query("SELECT * FROM `users` WHERE `user_name` = '$target_name'");
	if($findtarget->num_rows > 0){
		$info = $findtarget->fetch_array(MYSQLI_BOTH);
		$name = $info['user_name'];
		$avatar = $info['user_avatar'];
		$age = $info['user_age'];
		$rank = $info['user_rank'];
		$ip = $info['user_ip'];
		$email = $info['user_email'];
		$theme = $info['user_theme'];
		$action = date('n/d/y H:i', $info['last_action']);
		
		if($info['user_age'] == 0){
			$age = $lang_hidden;
		}
		else {
			$age = $age . " $lang_old";
		}
		if($info['user_sex'] == 0){
			$sex = $lang_hidden;
		}
		else{
			if($info['user_sex'] == 1){
				$sex = $lang_male;
			}
			elseif ($info['user_sex'] == 2){
				$sex = $lang_female;
			}
		}
		if($info['user_description'] == ''){
			$description = $name . " $lang_description";
		}
		elseif($info['user_description'] == 'you dont have set a description'){
			$description = $name . " $lang_description";
		}
		else{
			$description = $info['user_description'];
		}
		if($rank == 1){
			$rank = $lang_user;
		}
		elseif($rank == 2){
			$rank = $lang_vip;
		}
		elseif($rank == 3){
			$rank = $lang_mod;
		}
		elseif($rank == 4){
			$rank = $lang_admin;
		}
		elseif($rank == 5){
			$rank = $lang_sadmin;
		}
		if($info['guest'] == 1){
			$rank = $lang_guest;
		}
		echo "<div class=\"profile_user centered_element\">
				<p class=\"sub_color\">$name</p>
			</div>
			<div id=\"avatar\">
				<img class=\"profile_avatar\" src=\"avatar/$avatar\"/>
			</div>
			<div class=\"profile_info centered_element\">
				<div class=\"details_first\"><p><span class=\"sub_color\">$lang_rank:</span> $rank</p></div>
				<div class=\"details\"><p><span class=\"sub_color\">$lang_age:</span> $age</p></div>
				<div class=\"details\"><p><span class=\"sub_color\">$lang_sex:</span> $sex</p></div>";
			if($user['user_rank'] > 3){
				echo "<div class=\"details\"><p><span class=\"sub_color\">$lang_ip:</span> $ip</p></div>
					<div class=\"details\"><p><span class=\"sub_color\">$lang_theme:</span> $theme</p></div>
					<div class=\"details\"><p><span class=\"sub_color\">$lang_email:</span> $email</p></div>";
			}
			echo "<div class=\"details_last\"><p><span class=\"sub_color\">$lang_action:</span> $action</p></div>
			</div>
			<div class=\"profile_description_wrap centered_element profile_panel_description\">
				<div class=\"profile_description_title\">
					<p class=\"sub_color\">$lang_about</p>
				</div>
				<div class=\"profile_description\">
					<p>$description</p>
				</div>
			</div>";
	}
	else{
		echo "$lang_error";
	}
}
else{
	echo "$lang_error";
}
?>