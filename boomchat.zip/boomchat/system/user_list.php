<?php
/////////// BoomChat v 1.00 /////////////////
// all right reserved to Robert Barnab�
////////////////////////////////////////////
	require_once("config.php");

		if($user["user_access"] >= 1){
			$user_list = $mysqli->query("SELECT user_name, user_color, user_rank, alt_name, user_tumb, user_status, user_access FROM `users` WHERE `user_roomid` = {$user["user_roomid"]}  AND `user_status` <= 2 AND `user_access` != 2 AND `user_access` != 0 ORDER BY `user_status` ASC, `user_rank` DESC, `user_name` ASC ");
			if ($user_list->num_rows > 0)
			{
				echo "<div id=\"container_user\">";
				echo "<ul>";
				while ($list = $user_list->fetch_assoc())
				{
					if($list["alt_name"] == ""){
						$alt = "not set yet";
					}
					else{
					
						$alt = $list["alt_name"];
					}
					$uavatar = $list['user_tumb'];

					$avatar = "<img class=\"avatar_userlist\" src=\"avatar/$uavatar\"/>";
					if($list['user_status'] == 1){
						$away = $list['user_color'];
					}
					else {
						$away = "away";
					}
						if($list['user_access'] == 1){
							echo "<li class=\"users_option user_separator\">
									<div class=\"open_user  hover_element\">
										$avatar<p title=\"$alt\" class=\"$away usertarget\" id=\"{$list["user_name"]}\"><s>{$list["user_name"]}</s></p>
									</div>
									<div class=\"option_list\">
										<ul class=\"user_option_list\">";
											echo "<li class=\"sel_user user_option_separator hover_element\"><p class=\"get_info\" value=\"{$list["user_name"]}\">$usinfo</p></li>";
											if($list['user_name'] !== $user['user_name']){ 
												if($user['user_rank'] >= 3){
													echo "<li class=\"sel_user user_option_separator hover_element\"><p class=\"get_unmute\" value=\"{$list["user_name"]}\">$usunmute</p></li>";
												}
												if($user['user_rank'] > 4){
													echo "<li class=\"sel_user user_option_separator hover_element\"><p class=\"get_kill\" value=\"{$list["user_name"]}\">$usdelete</p></li>";
												}
											}
										echo "</ul>
									</div>
								</li>";	
						}
						else {
							echo "<li class=\"users_option user_separator\">
									<div class=\"open_user  hover_element\">
										$avatar<p title=\"$alt\" class=\"$away usertarget\" id=\"{$list["user_name"]}\">{$list["user_name"]}</p>
									</div>
									<div class=\"option_list\">
										<ul class=\"user_option_list\">";
											echo "<li class=\"sel_user user_option_separator hover_element\"><p class=\"get_info\" value=\"{$list["user_name"]}\">$usinfo</p></li>";
											if($list['user_name'] !== $user['user_name']){ 
												if($setting['allow_private'] == 1){ 
													echo "<li class=\"sel_user user_option_separator hover_element\"><p class=\"send_private\" value=\"{$list["user_name"]}\">$usprivate</p></li>"; 
												}
												if( $list['user_rank'] < 3 && $user['guest'] != 1){
													echo "<li class=\"sel_user user_option_separator hover_element\"><p class=\"get_ignore\" value=\"{$list["user_name"]}\">$usignore</p></li>";
												}
												if( $user['guest'] != 1){
													echo "<li class=\"sel_user user_option_separator hover_element\"><p class=\"get_friends\" value=\"{$list["user_name"]}\">$usfriends</p></li>";
												}
												if($user['user_rank'] >= 3){
													echo "<li class=\"sel_user user_option_separator hover_element\"><p class=\"get_mute\" value=\"{$list["user_name"]}\">$usmute</p></li>";
													echo "<li class=\"sel_user user_option_separator hover_element\"><p class=\"get_kick\" value=\"{$list["user_name"]}\">$uskick</p></li>";
												}
												if($user['user_rank'] > 3){
													echo "<li class=\"sel_user user_option_separator hover_element\"><p class=\"get_ban\" value=\"{$list["user_name"]}\">$usban</p></li>";
												}
												if($user['user_rank'] > 4){
													echo "<li class=\"sel_user user_option_separator hover_element\"><p class=\"get_kill\" value=\"{$list["user_name"]}\">$usdelete</p></li>";
												}
											}
										echo "</ul>
									</div>
								</li>";						
						}
				}	
				echo "</ul><div class=\"clear\"></div></div>";
			}
		}
		else {
			echo "<ul>
					<li>Room empty</li>
				</ul>";
		}


?>