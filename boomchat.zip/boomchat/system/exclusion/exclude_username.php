<?php 

// at the line bellow you can insert between the " " all the word that you do not want to authorize to be used inside a username 

$exclude_in_username = array( 'fuck', 'bitch' );
