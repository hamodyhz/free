<?php 
require_once("config_min.php");

// show and reload user avatar
if($user['user_access'] == 4 && $access == 'on'){

	echo "<img class=\"profile_avatar\" src=\"avatar/" . $user['user_avatar'] . "\"/>";
}
else {
	die();
}
?>