<?php
/////////// BoomChat /////////////////
// all right reserved to Robert Barnab�
////////////////////////////////////////////	
	require_once("config_min.php");
	if(isset($_POST['friend']) && $user['user_access'] == 4){
		$name = $user['user_name'];
		$add_this_friend = $mysqli->real_escape_string(trim($_POST['friend']));
		$target = $add_this_friend;
			$findfriend = $mysqli->query("SELECT `user_name`, `user_rank`  FROM `users` WHERE `user_name` = '$target'");
			if ($findfriend->num_rows > 0){
				$thisfriend = $findfriend->fetch_array(MYSQLI_BOTH);
				if($user['user_name'] !== $thisfriend['user_name']){
					$myfriend = $user['user_friends'];
					if(!strpos(strtolower($user['user_friends']), strtolower(" $target "))){
						$myfriend = trim($myfriend);
						$myfriend = " $myfriend $target ";
						$mysqli->query("UPDATE `users` SET `user_friends` = '$myfriend', `first_check` = '1' WHERE `user_name` = '$name'");
						echo 204;
						die();
					}
					else {
						echo 203;
						die();
					}
				}
				else {
					echo 3;
					die();
				}
			}
			else {
				echo 2;
				die();
			}
	}
	else{
		echo 2;
		die();
	}
?>