<?php require_once("config.php"); 



$uppath = $user["user_name"];
$picturepath = "../upload/$uppath/";
$filepath = "upload/$uppath/";
define('IMAGEPATH', $picturepath);


$filecount = glob(IMAGEPATH . '*');
$filecount = count($filecount);
	if($filecount > 0){
		foreach(glob(IMAGEPATH.'*') as $filename){
		  $files[filemtime($filename)] = $filename;
		}

		krsort($files);
		foreach($files as $filename) {
		$filesizepath = filesize("$filename");
		$filesizepath = $filesizepath / 1024;
		$filesizepath = round($filesizepath);
		$fileshowname = basename($filename);
		$filenameonly = str_replace(array('.jpg','.png','.gif'),'',basename($filename));
		$userpathlink = $user["user_name"];
						echo "<div class=\"image_container sub_element hover_element\">";
								echo  "<div class=\"view_image\"><a href=\"$filename\" class=\"fancybox\"><img src=\"icon/view_image.png\"/></a></div>";
								echo  "<div class=\"copy_image\"><img class=\"copy_link\" value=\"{$setting['domain']}/$filepath" . "$fileshowname\" src=\"icon/copy.png\"/></div>";
								echo  "<div class=\"link_image\"><p>$filenameonly</p></div>";
								echo "<div class=\"delete_image\"><img class=\"remove_image\" value=\"$fileshowname\"src=\"icon/close.png\"/></div>";
						echo "</div>";
		}
	}
	else {
		echo "$no_images";
	}
?> 