<?php
/////////// BoomChat /////////////////
// all right reserved to Robert Barnab�
////////////////////////////////////////////	
	require_once("config_min.php");
	$friend_count = 0;
	$user_list = $mysqli->query("SELECT user_name, user_status FROM users ORDER BY user_status ASC");
	$friend_list = $user['user_friends'];
	$friend_list = " $friend_list ";
	echo "<h3 class=\"friend_title\">$lang_friend_list</h3>";
	while($friend = $user_list->fetch_assoc()){
		$myfriend = $friend['user_name'];
		$myfriend = " $myfriend ";
		if(strpos(strtolower($friend_list), strtolower($myfriend))){
			if($friend['user_status'] == 1){
				$status = "online";
			}
			if($friend['user_status'] == 2){
				$status = "away";
			}
			if($friend['user_status'] == 3){
				$status = "gone";
			}
			echo "<div class=\"container_element sub_element hover_element\"><div class=\"wrap_element\"><div value=\"{$friend['user_name']}\" class=\"element_name friend_private\"><img class=\"friend_status\" src=\"./icon/" . $status . ".png\"/><p>{$friend['user_name']}</p></div><div class=\"delete_element delete_friend\"><button value=\"{$friend['user_name']}\" type=\"button\"><img class=\"close_room\" src=\"./icon/close.png\"/></button></div></div></div>";
			$friend_count = $friend_count + 1;
		}
	}
	if($friend_count < 1){
		echo "$lang_friend_list_empty";
	}
?>