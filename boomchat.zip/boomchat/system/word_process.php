﻿<?php
/////////// BoomChat v 1.00 /////////////////
// all right reserved to Robert Barnabé
////////////////////////////////////////////
require_once("config.php");
// add bad word to the database 
if(isset($_POST['word']) && $user['user_rank'] >= 4 && $user['user_access'] > 3){
	
	$word = $mysqli->real_escape_string(trim($_POST['word']));
	$mysqli->query("INSERT INTO `filter` (word) VALUES ('$word')");

}
// delete badword from the database
if(isset($_POST['delete_word']) && $user['user_rank'] >= 4){
	
	$word = $mysqli->real_escape_string(trim($_POST['delete_word']));
	$mysqli->query("DELETE FROM `filter` WHERE `word` = '$word'");

}


?>