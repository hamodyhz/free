		<div id="container_help">
			<h3 class="sub_color2 title_command"><?php echo $htstatus; ?></h3>
			<div value="<?php echo $cmdaway; ?>" class="wrap_command sub_element hover_element"><div class="command_copy "><p class="sub_color"><?php echo $cmdaway; ?></p></div><div class="effect"><p><?php echo $daway; ?><br /><?php echo $example; ?> <?php echo $cmdaway; ?></p></div><div class="clear"></div></div>			
			
			<h3 class="sub_color2 title_command"><?php echo $htspecial; ?></h3>
			<div value="<?php echo $cmdme; ?>" class="wrap_command sub_element hover_element"><div class="command_copy "><p class="sub_color"><?php echo $cmdme; ?></p></div><div class="effect"><p><?php echo $dme; ?><br /><?php echo $example; ?> <?php echo $cmdme; ?> <?php echo $htext; ?></p></div><div class="clear"></div></div>
			<div value="<?php echo $cmdmsg; ?>"  class="wrap_command sub_element hover_element"><div class="command_copy "><p class="sub_color"><?php echo $cmdmsg; ?></p></div><div class="effect"><p><?php echo $dmsg; ?><br /><?php echo $example; ?> <?php echo $cmdmsg; ?> <?php echo $huser; ?> <?php echo $htext; ?></p></div><div class="clear"></div></div>
			<div value="<?php echo $cmdseen; ?>" class="wrap_command sub_element hover_element"><div class="command_copy "><p class="sub_color"><?php echo $cmdseen; ?></p></div><div class="effect"><p><?php echo $dseen; ?><br /><?php echo $example; ?> <?php echo $cmdseen; ?> <?php echo $huser; ?></p></div><div class="clear"></div></div>
			<?php if ($user['guest'] !== 1){
						echo "<div value=\"$cmdfriend\"  class=\"wrap_command sub_element hover_element\"><div class=\"command_copy \"><p class=\"sub_color\">$cmdfriend</p></div><div class=\"effect\"><p>$dfriend<br />$example $cmdfriend $huser</p></div><div class=\"clear\"></div></div>";
					}
			?>
			<?php if ($user['user_rank'] > 3){
						echo "<div value=\"$cmdglobal\"  class=\"wrap_command sub_element hover_element\"><div class=\"command_copy \"><p class=\"sub_color\">$cmdglobal</p></div><div class=\"effect\"><p>$dglobal<br />$example $cmdglobal $htext</p></div><div class=\"clear\"></div></div>";
					}
			?>
			
			<?php if ($user['user_rank'] > 2){
					echo "<h3 class=\"sub_color2 title_command\">$htrooms</h3>";
					echo "<div value=\"$cmdtopic\" class=\"wrap_command sub_element hover_element\"><div class=\"command_copy \"><p class=\"sub_color\">$cmdtopic</p></div><div class=\"effect\"><p>$dtopic<br />$example $cmdtopic $htopic</p></div><div class=\"clear\"></div></div>
					<div value=\"$cmdclear\" class=\"wrap_command sub_element hover_element\"><div class=\"command_copy \"><p class=\"sub_color\">$cmdclear</p></div><div class=\"effect\"><p>$dclear<br />$example $cmdclear</p></div><div class=\"clear\"></div></div>";
					}
			?>
			<?php if ($user['user_rank'] > 3){
					echo "<div value=\"$cmdclear $cmdclearall\" class=\"wrap_command sub_element hover_element\"><div class=\"command_copy \"><p class=\"sub_color\">$cmdclear $cmdclearall</p></div><div class=\"effect\"><p>$dclearall<br />$example $cmdclear $cmdclearall</p></div><div class=\"clear\"></div></div>
					<div value=\"$cmdrename\" class=\"wrap_command sub_element hover_element\"><div class=\"command_copy \"><p class=\"sub_color\">$cmdrename</p></div><div class=\"effect\"><p>$drename<br />$example $cmdrename $hroom</p></div><div class=\"clear\"></div></div>";
					}
			?>
			
			<h3 class="sub_color2 title_command"><?php echo $htprivate; ?></h3>
			<div value="<?php echo $cmdclear; ?>" class="sub_element hover_element"><div class="command_copy "><p class="sub_color"><?php echo $cmdclear; ?></p></div><div class="effect"><p><?php echo $dclearp; ?><br /><?php echo $example; ?> <?php echo $cmdclear; ?></p></div><div class="clear"></div></div>
			
			<?php if ($user['user_rank'] > 2){
				echo "<h3 class=\"sub_color2 title_command\">$htcontrol</h3>";
				echo "<div value=\"$cmdmute\" class=\"wrap_command sub_element hover_element\"><div class=\"command_copy \"><p class=\"sub_color\">$cmdmute</p></div><div class=\"effect\"><p>$dmute<br />$example $cmdmute $huser</p></div><div class=\"clear\"></div></div>
					<div value=\"$cmdkick\" class=\"wrap_command sub_element hover_element\"><div class=\"command_copy \"><p class=\"sub_color\">$cmdkick</p></div><div class=\"effect\"><p>$dkick<br />$example $cmdkick $huser</p></div><div class=\"clear\"></div></div>
					<div value=\"$cmdunmute\" class=\"wrap_command sub_element hover_element\"><div class=\"command_copy \"><p class=\"sub_color\">$cmdunmute</p></div><div class=\"effect\"><p>$dunmute<br />$example $cmdunmute $huser</p></div><div class=\"clear\"></div></div>
					<div value=\"$cmdupon\" class=\"wrap_command sub_element hover_element\"><div class=\"command_copy \"><p class=\"sub_color\">$cmdupon</p></div><div class=\"effect\"><p>$dupon<br />$example $cmdupon $huser</p></div><div class=\"clear\"></div></div>
					<div value=\"$cmdupoff\" class=\"wrap_command sub_element hover_element\"><div class=\"command_copy \"><p class=\"sub_color\">$cmdupoff</p></div><div class=\"effect\"><p>$dupoff<br />$example $cmdupoff $huser</p></div><div class=\"clear\"></div></div>";
					}
				echo "<div value=\"$cmdignore\" class=\"wrap_command sub_element hover_element\"><div class=\"command_copy \"><p class=\"sub_color\">$cmdignore</p></div><div class=\"effect\"><p>$dupoff<br />$example $cmdignore $huser</p></div><div class=\"clear\"></div></div>";
				echo "<div value=\"$cmdignclear\" class=\"wrap_command sub_element hover_element\"><div class=\"command_copy \"><p class=\"sub_color\">$cmdignclear</p></div><div class=\"effect\"><p>$dupoff<br />$example $cmdignclear</p></div><div class=\"clear\"></div></div>";

			?>
			<?php if ($user['user_rank'] > 3){
				echo "<div value=\"$cmdban\" class=\"wrap_command sub_element hover_element\"><div class=\"command_copy \"><p class=\"sub_color\">$cmdban</p></div><div class=\"effect\"><p>$dban<br />$example $cmdban $huser</p></div><div class=\"clear\"></div></div>
					<div value=\"$cmdsetuser\" class=\"wrap_command sub_element hover_element\"><div class=\"command_copy \"><p class=\"sub_color\">$cmdsetuser</p></div><div class=\"effect\"><p>$dsetuser<br />$example $cmdsetuser $huser</p></div><div class=\"clear\"></div></div>
					<div value=\"$cmdsetmod\" class=\"wrap_command sub_element hover_element\"><div class=\"command_copy \"><p class=\"sub_color\">$cmdsetmod</p></div><div class=\"effect\"><p>$dsetmod<br />$example $cmdsetmod $huser</p></div><div class=\"clear\"></div></div>
					<div value=\"$cmdinvisible\" class=\"wrap_command sub_element hover_element\"><div class=\"command_copy \"><p class=\"sub_color\">$cmdinvisible</p></div><div class=\"effect\"><p>$dinvisible<br />$example $cmdinvisible</p></div><div class=\"clear\"></div></div>
					<div value=\"$cmdvisible\" class=\"wrap_command sub_element hover_element\"><div class=\"command_copy \"><p class=\"sub_color\">$cmdvisible</p></div><div class=\"effect\"><p>$dvisible<br />$example $cmdvisible</p></div><div class=\"clear\"></div></div>";
					}
			?>
			<?php if ($user['user_rank'] >= 3){
				echo "<div value=\"$cmdsetvip\" class=\"wrap_command sub_element hover_element\"><div class=\"command_copy \"><p class=\"sub_color\">$cmdsetvip</p></div><div class=\"effect\"><p>$dsetvip<br />$example $cmdsetvip $huser</p></div><div class=\"clear\"></div></div>";
					}
			?>
			<?php if ($user['user_rank'] > 4){
				echo "<div value=\"$cmdsetadmin\" class=\"wrap_command sub_element hover_element\"><div class=\"command_copy \"><p class=\"sub_color\">$cmdsetadmin</p></div><div class=\"effect\"><p>$dsetadmin<br />$example $cmdsetadmin $huser</p></div><div class=\"clear\"></div></div>";
				echo "<div value=\"$cmdsilent\" class=\"wrap_command sub_element hover_element\"><div class=\"command_copy \"><p class=\"sub_color\">$cmdsilent</p></div><div class=\"effect\"><p>$dsilent<br />$example $cmdsilent $hsilent</p></div><div class=\"clear\"></div></div>";
				echo "<div value=\"$cmdgsound\" class=\"wrap_command sub_element hover_element\"><div class=\"command_copy \"><p class=\"sub_color\">$cmdgsound</p></div><div class=\"effect\"><p>$dgsound<br />$example $cmdgsound</p></div><div class=\"clear\"></div></div>";
					}
			?>
		
			<?php if ($user['user_rank'] > 4){
				echo "<h3 class=\"sub_color2 title_command\">$httheme</h3>";
				echo "<div value=\"$cmdaddtheme\" class=\"wrap_command sub_element hover_element\"><div class=\"command_copy \"><p class=\"sub_color\">$cmdaddtheme</p></div><div class=\"effect\"><p>$daddtheme<br />$example $cmdaddtheme $htheme</p></div><div class=\"clear\"></div></div>
					<div value=\"$cmddeltheme\" class=\"wrap_command sub_element hover_element\"><div class=\"command_copy \"><p class=\"sub_color\">$cmddeltheme</p></div><div class=\"effect\"><p>$ddeltheme<br />$example $cmddeltheme $htheme</p></div><div class=\"clear\"></div></div>";
					}
			?>
			<?php if ($user['user_rank'] >= 3){
				echo "<h3 class=\"sub_color2 title_command\">$htdocu</h3>";
				echo "<div value=\"$cmdmanual\" class=\"wrap_command sub_element hover_element\"><div class=\"command_copy \"><p class=\"sub_color\">$cmdmanual</p></div><div class=\"effect\"><p>$dmanual<br />$example $cmdmanual</p></div><div class=\"clear\"></div></div>";
					}
			?>
			<?php
				if($user['user_rank'] > 4){
				echo "<h3 class=\"sub_color2 title_command\">$htadmin</h3>";
				echo "<div value=\"$cmdinstall\" class=\"wrap_command sub_element hover_element\"><div class=\"command_copy \"><p class=\"sub_color\">$cmdinstall</p></div><div class=\"effect\"><p>$dinstall<br />$example $cmdinstall $haddons</p></div><div class=\"clear\"></div></div>";
				echo "<div value=\"$cmduninstall\" class=\"wrap_command sub_element hover_element\"><div class=\"command_copy \"><p class=\"sub_color\">$cmduninstall</p></div><div class=\"effect\"><p>$duninstall<br />$example $cmduninstall $haddons</p></div><div class=\"clear\"></div></div>";
				echo "<div value=\"$cmdupdate\" class=\"wrap_command sub_element hover_element\"><div class=\"command_copy \"><p class=\"sub_color\">$cmdupdate</p></div><div class=\"effect\"><p>$dupdate<br />$example $cmdupdate</p></div><div class=\"clear\"></div></div>";
				}
			?>
		</div>