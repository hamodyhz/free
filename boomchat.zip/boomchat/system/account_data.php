<?php
require_once("config_min.php");

if(isset($_POST['set_age']) && isset($_POST['set_gender']) && isset($_POST['set_description'])){

	$me = $user['user_name'];
	$my_age = $mysqli->real_escape_string(trim($_POST['set_age']));
	$my_gender = $mysqli->real_escape_string(trim($_POST['set_gender']));
	$my_description = $mysqli->real_escape_string(trim($_POST['set_description']));
	$my_sound = $mysqli->real_escape_string(trim($_POST['set_sound']));

	if(!empty( $_POST["set_description"] )){
		$my_description = $my_description;
	}
	else {
		$my_description = $user['user_description'];
	}
	$findtarget = $mysqli->query("SELECT `user_access` FROM `users` WHERE `user_name` = '$me'");
	if($findtarget->num_rows > 0){
		$mysqli->query("UPDATE `users` SET `user_age` = '$my_age', `user_sex` = '$my_gender', `user_description` = '$my_description', `user_sound` = $my_sound WHERE `user_name` = '$me'");
		echo 1;
	}
	else {
		echo 2;
	}
}
else{
	echo 2;
}
?>