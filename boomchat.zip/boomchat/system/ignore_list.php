<?php
/////////// BoomChat /////////////////
// all right reserved to Robert Barnab�
////////////////////////////////////////////	
	require_once("config_min.php");
		
		// show rooms list
		if($user["user_access"] >= 1){
			$list = trim($user['user_ignore']);
			if($list !== ""){
				$ignore = explode(' ',trim($user['user_ignore']));
				foreach($ignore as $result) {
					echo "<div class=\"container_element sub_element hover_element\"><div class=\"wrap_element\"><div class=\"element_name\"><p>$result</p></div><div class=\"delete_element delete_ignore\"><button value=\"$result\" type=\"button\"><img class=\"close_room\" src=\"./icon/close.png\"/></button></div></div></div>";
				}
			}
			else {
				echo "$ignore_empty";
			}
		}
		else {
			echo "<div>$lang_error</div>";
		}
		?>