<?php	
/////////// BoomChat v 1.00 /////////////////
// all right reserved to Robert Barnab�
////////////////////////////////////////////
require_once("config_min.php");

// show the topic for current room
$myroom = $user['user_roomid'];
if($user["user_access"] >= 1){
	$room_topic = $mysqli->query("SELECT `room_name`, `topic` FROM `rooms` WHERE `room_id` = '$myroom'");
	if ($room_topic->num_rows > 0)
	{
		$topic = $room_topic->fetch_array(MYSQLI_BOTH);
		if ($topic['topic'] != ''){
			$finaltopic = $topic['topic'];
			$finalroom = $topic['room_name'];
			echo "<span class=\"topic sub_color\">$topicname</span> : $finaltopic";
		}
		else {
			echo "<span class=\"topic sub_color\">Topic</span> : $msgtopic";
		}
	}
}
else {
	echo "<span class=\"topic sub_color\">Topic</span> : $msgtopic";
}
?>