<?php
require_once("../system/config.php");

	$history_lenght = $setting['log_history'];
	echo "<ul id=\"ul_history\" class=\"background_box\">";
		if($user['user_access'] == 1 || $user['user_access'] == 4 ){
			$user_room = $user['user_roomid'];
			$history = $mysqli->query("SELECT * FROM `chat` WHERE `post_roomid` = $user_room AND `type` = 'public' OR `post_roomid` = $user_room AND `type` = 'me' OR `post_roomid` = $user_room AND `type` = 'system' OR `post_roomid` = $user_room AND `type` = 'global' ORDER BY `post_id` DESC LIMIT $history_lenght");
			
			while ($log = $history->fetch_assoc()){
				$myself = $user['user_name'];
				$myself2 = strtolower($myself);
				$message = str_replace(array(" $myself","$myself2 "), "<span class=\"my_notice\">$myself</span>", $log['post_message']);
				$message = emoticon(linking($message));
				if ($log['type'] == 'me'){
					echo "<li class=\"{$log["type"]}\"><span class='datechat'>{$log["post_time"]} </span> <span class='username {$log["post_color"]}'>{$log["post_user"]}</span> $message</li>\n";
				}
				else{
					echo "<li class=\"{$log["type"]}\"><span class='datechat'>{$log["post_time"]} </span> <span class='username {$log["post_color"]}'>{$log["post_user"]}</span> : $message</li>\n";
				}
				
			}
		}
		else{
			echo "$lang_error";
		}
	echo "</ul>";
?>