<?php	require_once("config_min.php");
?>

<?php 
	if ($user["user_access"] == 4){
	
	
	
		$target = $mysqli->real_escape_string(trim($_POST['target']));
		$me = $user["user_name"];
		
		
		$mysqli->query("UPDATE `private` SET `status` = 3, `view` = 1  WHERE `hunter` = '$target' AND `target` = '$me'");
		echo 1;
	}
	else {
		die();
	}

?>