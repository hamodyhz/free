<?php	require_once("config_min.php"); 

if (isset($_POST['target']) && isset($_POST['message'])){

	$target = $mysqli->real_escape_string(trim($_POST['target']));
	$message = linking($mysqli->real_escape_string(trim($_POST['message'])));

	$finduser = $mysqli->query("SELECT `user_color`, `guest`, `user_ignore` FROM `users` WHERE `user_name` = '$target'");
	if ($finduser->num_rows > 0){
	
			$targetfound = $finduser->fetch_array(MYSQLI_BOTH);
			if(!strpos(strtolower($targetfound['user_ignore']), strtolower($user['user_name']))){
				$mycolor = $user["user_color"];
				$target_color = $targetfound["user_color"];
				$guest_post = $targetfound["guest"];
				$hunterid = $user["user_id"];
				$hunter = $user["user_name"];
				if($guest_post == 1 || $user['guest'] == 1){
					$gupost = 1;
				}
				else {
					$gupost = 0;
				}
				if($message == $cmdclear){
					$mysqli->query("DELETE FROM private WHERE hunter = '$hunter' AND target = '$target' OR hunter = '$target' AND target = '$hunter'");
				}
				else {
					$mysqli->query("INSERT INTO `private` (time, target, hunter, message, target_color, hunter_color, hunter_guest) VALUES ('$time', '$target', '$hunter', '$message', '$target_color', '$mycolor', '$gupost')");
				}
			}
			else {
				die();
			}
	}
	else{
		echo 2;
	}
}
else {
	echo 4;
}



?>