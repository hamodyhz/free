<?php
require_once("config.php"); 



echo "<div id=\"login_error\"><div class=\"error\" id=\"login_error_inside\"></div></div>
		<form class=\"login_form\" autocomplete=\"off\">
			<input style=\"display:none\">
			<input type=\"password\" style=\"display:none\">
			<p class=\"login_label\">$lang_username</p>
			<input id=\"user_username\" class=\"input_data background_box\" type=\"text\" maxlength=\"{$setting['max_username']}\" name=\"username\">
			<p class=\"login_label\">$lang_password</p>
			<input id=\"user_password\" class=\"input_data background_box\" maxlength=\"30\" type=\"password\" name=\"password\"><br />
			<p class=\"login_label sub_color forgot_password\">$lang_forgot</p>
			<div id=\"login_button\" class=\"sub_button hover_element\"><p>$lang_login</p></div>";
			
			if($setting['registration'] == 1)
			{
				echo "<div id=\"login_register\"><p>$lang_register</p></div>";
				echo "<div class=\"clear\"></div>";
			}
			if($setting['allow_guest'] == 1){
				echo "<div class=\"sub_button hover_element\" id=\"guest_button\"><p>$guest_button</p></div>";
			}
			echo "</form>";

?>