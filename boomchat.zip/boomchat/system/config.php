<?php
	$time = ceil(time());
	$access = 'on';
	require_once("database.php");
	require_once("content_process.php");
	
	$mysqli = @new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
	
	if (mysqli_connect_errno() || $check_install != 1) 
	{
		if($check_install != 1){
			$chat_install = 2;
		}
		else{
			$chat_install = 3;
		}
	}
	else{
		$chat_install = 1;
		$setting = mysqli_fetch_array($mysqli->query("SELECT * FROM `setting`"));
		if (!isset($_COOKIE["username"]) || !isset($_COOKIE["password"])){
			$access = 'off';
		}
		else
		{
			$cookiepass = $mysqli->real_escape_string(trim($_COOKIE["password"]));
			$cookieuser = $mysqli->real_escape_string(trim($_COOKIE["username"]));
			$exist = $mysqli->query("SELECT * FROM `users` WHERE `user_password` = '{$cookiepass}' AND `user_name` = '{$cookieuser}'");
			if($exist->num_rows > 0){
			$user = mysqli_fetch_array($mysqli->query("SELECT * FROM `users` WHERE `user_password` = '{$cookiepass}' AND `user_name` = '{$cookieuser}' "));
			}
			else{
				$access = 'off';
				setcookie("username","",time()-100000);
				setcookie("password","",time()-100000);
			}
			
		}
		require_once("language/" . $setting['language'] . "/language.php"); 
	}
	date_default_timezone_set('America/Montreal');
?>