<?php

// you can edit these lines to configure new setting for your chat

$DB_HOST = "host"; //  replace host by your server host in most case is localhost.
$DB_USER = "user"; // replace user by username to connect to database
$DB_PASS = "password"; // replace password by password used to connect to database
$DB_NAME = "dbname"; // replace dbname with your database name


// replace encryption  with any encryption key for password ex : l0()(#&$)(&)@()@(%)(%*ksljsr 
// Please do not modify this line post installation

$encryption = "encryption";

$check_install = 0; // once all information are filled up correctly change 0 to 1
?>