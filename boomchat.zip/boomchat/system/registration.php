<?php
require_once("config.php"); 

if($setting['registration'] == 1 ){

echo "<div id=\"login_error\"><div class=\"error\" id=\"login_error_inside\"></div></div>
<form class=\"login_form\" autocomplete=\"off\">
	<input style=\"display:none\">
	<input type=\"password\" style=\"display:none\">
	<p class=\"login_label\">$lang_username</p>
	<input id=\"reg_username\" class=\"input_data background_box\" type=\"text\" maxlength=\"{$setting['max_username']}\">
	<p class=\"login_label\">$lang_password</p>

	<input id=\"reg_password\" class=\"input_data background_box\" maxlength=\"30\" type=\"password\">
	<p class=\"login_label\">$lang_email</p>
	<input id=\"reg_email\" class=\"input_data background_box\" maxlength=\"80\" type=\"text\">
	<div class=\"sub_button hover_element\" id=\"register_button\"><p>$lang_register</p></div>
	<div id=\"login_login\"><p>$lang_login</p></div>
</form>";
}
else {
	echo 1;
}

?>