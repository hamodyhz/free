<?php
	require_once("config_min.php");
	$theme = $mysqli->query("SELECT * FROM `theme` WHERE `id` >=  1");
	if ($theme->num_rows > 0)
	{
		echo "<div id=\"theme_title\"><p>$availtheme</p></div>";
		echo "<div id=\"container_user_room\">";
			while ($themes = $theme->fetch_assoc())
			{
				$theme_name = $themes["name"];
				$theme_name = str_replace("_", " ", $theme_name);
				if ( $user['user_theme'] == $themes["name"] ) {
					echo "<div class=\"theme_button selected_theme selected_element  hover_element\" value=\"{$themes["name"]}\"><p>$theme_name</p></div>";
				}
				else {
					echo "<div class=\"theme_button new_theme sub_element hover_element\" value=\"{$themes["name"]}\"><p>$theme_name</p></div>";
				}
			}
		echo "</div>";
	}
	else {
		die();
	}



?>