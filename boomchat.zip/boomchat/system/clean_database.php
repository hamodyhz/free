<?php	require_once("config.php");

	if($setting['data_delete'] == 60){
		$clean_time = $time - ($setting['data_delete'] * 60);
	}
	else {
		$clean_time = $time - ($setting['data_delete'] * 604800);
	}
	$clean_guest = $time - ($setting['guest_clear'] - 1);
	
	// clean the database based on superadmin setting time
	if($user['user_rank'] > 3 && $user['user_access'] == 4){
		$mysqli->query("DELETE FROM `chat` WHERE `post_date` < '$clean_time' ");
		$mysqli->query("DELETE FROM `private` WHERE `time` < '$clean_time' ");
		$mysqli->query("DELETE FROM `users` WHERE `last_action` < '$clean_guest' AND `guest` = '1'");
		$mysqli->query("DELETE FROM `private` WHERE `time` < '$clean_guest' AND `hunter_guest` = '1'");
		echo "success";
	}
	else{
		die();
	}
?>