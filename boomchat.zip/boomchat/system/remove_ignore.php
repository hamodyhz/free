<?php
/////////// BoomChat /////////////////
// all right reserved to Robert Barnab�
////////////////////////////////////////////	
	require_once("config_min.php");
		
	if(isset($_POST['delete_ignore']) && $user['user_access'] == 4){
		$remove = $mysqli->real_escape_string(trim($_POST['delete_ignore']));
		$me = $user['user_name'];
		$list = $user['user_ignore'];
		$new_list = str_replace(" $remove ", " ", $list);
		$mysqli->query("UPDATE `users` SET `user_ignore` = '$new_list', `first_check` = '1' WHERE `user_name` = '$me'");
		echo 1;
	}
	else{
		echo 2;
		die();
	}
?>