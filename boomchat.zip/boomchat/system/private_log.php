<?php	require_once("config_min.php");
?>

<?php 
	if ($user["user_access"] == 4){
	
	
	
		$target = $mysqli->real_escape_string(trim($_GET['target']));
		$hunter = $user["user_name"];
		
		
		$log = $mysqli->query("SELECT * FROM `private` WHERE `hunter` = '$hunter' AND `target` = '$target'  OR `hunter` = '$target' AND `target` = '$hunter' ORDER BY `id` DESC LIMIT 15");
		$mysqli->query("UPDATE `private` SET `status` = 1 WHERE `hunter` = '$target' AND `target` = '$hunter'");
		
		if ($log->num_rows > 0){
			while ($chat = $log->fetch_assoc()){
			
			$message = str_replace(array(':)',':P',':D',':(',';)',':-O'),array(':smile4:',':tongue4:',':happy2:',':cry4:',':blink:',':woot:'), $chat['message']);
				$message = emoticon($message);
				if($chat['hunter'] == $user['user_name']){
					echo "<li class=\"hunter_private\">$message </li>\n";
				}
				else {
					echo "<li class=\"target_private\">$message </li>\n";
				}
			}
		}
		else {
			echo "<li>$emptyprivate</li>";
		}
	}
	else{
		echo "<li>$lang_error</li>";
	}

?>