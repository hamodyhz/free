<?php	require_once("config.php");
$username = $user['user_name'];

// upload new avatar and delete old avatar to the server
if($access == 'on' && $user['user_access'] == 4){
	$picturepath = "avatar/";
	define('IMAGEPATH', $picturepath);

	if (isset($_FILES["file"])){
		if ((($_FILES["file"]["type"] == "image/gif")
		|| ($_FILES["file"]["type"] == "image/jpeg")
		|| ($_FILES["file"]["type"] == "image/jpg")
		|| ($_FILES["file"]["type"] == "image/png"))
		|| ($_FILES["file"]["type"] == "image/JPG")
		&& ($_FILES["file"]["size"] < 1024 )
		&& in_array($extension, $allowedExts)){
			if ($_FILES["file"]["error"] > 0){
				echo 2;
			}
			else{					  
				if (($_FILES["file"]["size"] / 1024) > $setting['max_avatar']){
					echo $setting['max_avatar'];										
				}
				else{
				 $images_user =  str_replace(str_split('\\/:*?"<>-@&%|'), '' , preg_replace('/\s+/', '', $_FILES["file"]["name"]));
				 $unlinklink = "../avatar/{$user["user_avatar"]}";
				 $tumbname = str_replace(array('.jpg','.JPG','.jpeg','.png','.gif'),array('_tumb.jpg','_tumb.JPG','_tumb.jpeg','_tumb.png','_tumb.gif'),$user['user_avatar']);
				 $unlinktumb = "../avatar/$tumbname";
					if (file_exists($unlinklink) && $unlinklink != '../avatar/default_avatar.png'){
						unlink($unlinklink);
					}
					if (file_exists($unlinktumb) && $unlinktumb != '../avatar/default_avatar_tumb.png'){
						unlink($unlinktumb);
					}
				$ext = explode('.',$_FILES['file']['name']);
				$extension = $ext[1];
				$count = rand(0,99999999);
				$file_name = "$username" . "$count" . "."."$extension";
				 move_uploaded_file(preg_replace('/\s+/', '', $_FILES["file"]["tmp_name"]),
				 "../avatar/" . "$file_name");
				 $path = "../avatar/$file_name";
				 createThumbnail($path);
				 $tumb_new = str_replace(array('.jpg','.JPG','.jpeg','.png','.gif'),array('_tumb.jpg','_tumb.JPG','_tumb.jpeg','_tumb.png','_tumb.gif'),$file_name);
				 
				$filename = "../avatar/$tumb_new";
				if (file_exists($filename)) {
					$tumb_new = $tumb_new;
				}
				else {
					$tumb_new = "default_avatar_tumb.png";
				}
				 $mysqli->query("UPDATE `users` SET `user_avatar` = '$file_name', `user_tumb` = '$tumb_new'  WHERE `user_id` = '{$user["user_id"]}'");
				 $mysqli->query("UPDATE `chat` SET `avatar` = '$tumb_new'  WHERE `post_user` = '{$user["user_name"]}'");
				 echo 5;
				}
			} 
		}
		else{
			echo 4;
		}
	}
	else {
		echo 3;
	}
}
else {
	echo 1;
}





?>