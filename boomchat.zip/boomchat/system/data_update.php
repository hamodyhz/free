<?php
require_once("config.php"); 
		
		$me = $user['user_name'];
		$room = $user['user_roomid'];
		
		$sound = $user['user_sound'];
		$sound = $sound - 0;
		$whistle = 1;
		
		if($setting['version'] >= 4){
			$whistle = $setting['global_sound'];
		}
		
		// check ads content & values 
		
		$atime = $setting['ads_time'];
		$aallow = $setting['allow_ads'];
		$aselect = $setting['ads_select'];
		$adelay = $setting['ads_delay'];
		$aacount = $setting['ads_count'];
		$checkdelay = $time - $setting['ads_delay'];
		$stop = $setting['ads_stop'];
		
			if($atime < $checkdelay){
				if($aselect < $aacount){
					$aselect = $aselect + 1;
				}
				else {
					$aselect = 1;
				}
				$mysqli->query("UPDATE `setting` SET `ads_select` = '$aselect', `ads_time` = '$time'");
			}

	
		// check for last message on the chat
				$log = $mysqli->query("SELECT `post_message` FROM `chat` WHERE 
				`post_message` LIKE '%$me%' AND `post_user` != '$me' AND `type` = 'public' OR
				`post_message` LIKE '%$me%' AND `post_user` != '$me' AND `type` = 'me' OR
				`post_message` LIKE '%$me%' AND `post_user` != '$me' AND `type` = 'global'
				ORDER BY `post_id` DESC LIMIT 1");
				
				if ($log->num_rows > 0){
					$last = $log->fetch_assoc();
					$last = $last['post_message'];
				}
				else{
					$last = "nothing found";
				}
		
		// check if there is new private message
		
		$last_private = $mysqli->query("SELECT `message` FROM `private` WHERE `target` = '$me' AND `hunter` != '$me' ORDER BY `time` DESC LIMIT 1");
		$new_private = $last_private->fetch_assoc();
		$private = $new_private['message'];
		$private = addslashes($private);
		
		$private_icon = $mysqli->query("SELECT  `status`FROM `private` WHERE `target` = '$me' AND `status` = 0  AND `hunter` != '$me'");
		$icon_result = $private_icon->num_rows;
		
		
		// return value of data to jquery as a json variable
		echo json_encode(
			array("bet3" => $sound, "bet4" => $private, "bet5" => $last, "bet7" => $aallow, "bet8" => $aselect, "bet9" => $stop, "bet12" => $icon_result, "bet13" => $whistle));
?>