<?php 
/////////// BoomChat v 1.00 /////////////////
// all right reserved to Robert Barnab�
////////////////////////////////////////////
require_once("config.php"); 
	// set user account to theme selected
	if (isset($_POST['theme']) && $user['user_access'] == 4 && $setting['allow_theme'] == 1){
		
		$target = $user['user_id'];
		$theme= $mysqli->real_escape_string(trim($_POST['theme']));
		$mysqli->query("UPDATE `users` SET `user_theme` = '$theme' WHERE `user_id` = $target");
	}
	else{
		echo 1;
	}

?>