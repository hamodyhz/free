<?php require_once("config_min.php"); 
	if($user['upload_access'] != 1){ die(); }
?>
<?php
$uppath = $user["user_name"];
$picturepath = "upload/$uppath/";
define('IMAGEPATH', $picturepath);

if(isset($_POST['del_image'])) { 
		$filedelete = $_POST['del_image']; 
		if (strpos($filedelete,'..')){
			die();
		}
		else{
			$filedelete = str_replace(array('..'),array(''),$filedelete);
			$unlinklink = "../upload/$uppath/$filedelete";
			unlink($unlinklink);
			$mysqli->query("UPDATE `users` SET `upload_count` = `upload_count` - 1 WHERE `user_name` = '{$user["user_name"]}'");
			echo 1;
}
}






?>