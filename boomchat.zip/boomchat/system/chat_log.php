<?php	
	require_once("config.php");
	if ($access == 'off'){
		echo 4;
		die();
	}
	// check for information sent by user
	if(isset($_GET['rank']) && isset($_GET['access']) && isset($_GET['room']) && isset($_GET['bottom'])){
		if($setting['orientation'] !== $_GET['bottom']){
			echo 1000;
			die();
		}
		$room = htmlspecialchars($_GET['room']);
		$rank = htmlspecialchars($_GET['rank']);
		$access = htmlspecialchars($_GET['access']);
		if($user['user_rank'] == $rank && $user['user_access'] == $access && $setting['maintenance'] == 1 && $user['user_access'] > 0 || $user['user_rank'] == $rank && $user['user_access'] == $access && $user['user_rank'] >= 3 && $user['user_access'] > 0){

			$user_check = $user['first_check'];
			$new_logs = $mysqli->query("SELECT * FROM `chat` WHERE  `post_date` >= '$user_check'");
			if($new_logs->num_rows > 0 || $user['join_chat'] < 4){


				if($user['user_roomid'] == $_GET['room']){
				
					$history_chat = $setting['chat_history'];
					$join = $user['join_chat'] + 1;
					$me = $user['user_name'];
					$me2 = strtolower($me);
					$logs = 1;
					
						if($setting['orientation'] == 1){		
							$log = $mysqli->query("SELECT * FROM `chat` WHERE `post_roomid` = '$room' AND `type` = 'public' OR `type` = 'system' AND `post_roomid` = '$room' OR `post_roomid` =  '$room' AND `type` = 'seen' AND `post_target` = '$me' OR `type` = 'private' AND `post_target` = '$me' AND `post_roomid` = '$room'  OR `type` = 'private' AND `post_user` = '$me' AND `post_roomid` = '$room' OR `post_roomid` = '$room' AND `type` = 'me' OR `post_roomid` = '$room' AND `type` = 'global' ORDER BY `post_id` DESC LIMIT $history_chat");
						}
						else {
							$log = $mysqli->query("SELECT * FROM ( SELECT * FROM `chat` WHERE `post_roomid` = '$room' AND `type` = 'public' OR `type` = 'system' AND `post_roomid` = '$room' OR `post_roomid` = '$room' AND `type` = 'seen' AND `post_target` = '$me' OR `type` = 'private' AND `post_target` = '$me' AND `post_roomid` = '$room'  OR `type` = 'private' AND `post_user` = '$me' AND `post_roomid` = '$room' OR `post_roomid` = '$room' AND `type` = 'me' OR `post_roomid` = '$room' AND `type` = 'global' ORDER BY `post_id` DESC LIMIT $history_chat) AS log ORDER BY `post_date` ASC");
						}
						
						if ($log->num_rows > 0){
							$mysqli->query("UPDATE `users` SET `first_check` = '$time', `join_chat` = '$join' WHERE `user_name` = '$me'");
							while ($chat = $log->fetch_assoc()){
								if($logs == 1){
									$lcolor = 'log1';
								}
								else {
									$lcolor = 'log2';
								}
								$uavatar = $chat['avatar'];
								if($uavatar == ''){
									$uavatar = 'default_avatar_tumb.png';
								}
								$avatar = "<img class=\"avatar_chat\" src=\"avatar/$uavatar\"/>";
								$message = str_replace(array(':)',':P',':D',':(',';)',':-O'," $me","$me "," $me2","$me2 "),array(':smile4:',':tongue4:',':happy2:',':cry4:',':blink:',':woot:',"<span class=\"my_notice\">$me</span>","<span class=\"my_notice\">$me</span>","<span class=\"my_notice\">$me</span>","<span class=\"my_notice\">$me</span>"), $chat['post_message']);
									
								if($setting['allow_link'] == 1){
									$message = emoticon(linking($message));
								}
								else{
									$message = emoticon($message);
								}
									if(!strpos(strtolower($user['user_ignore']), strtolower($chat['post_user']))){
										if($user['user_rank'] >= 3){
												if( strtolower($chat['post_target']) == strtolower($user['user_name']) && $chat['post_user'] != "$lang_system"){
													echo "<li class=\"ch_logs $lcolor " . $chat['type'] . "\"><div value=\"" . $chat['post_user'] . "\" class=\"my_avatar chat_avatar_wrap\">$avatar</div><div class=\"my_text\"><p><span class=\"username " . $chat['post_color'] . "\">" . $chat['post_user'] . "</span> : $message<span class=\"private_reply\" value=\"" . $chat['post_user'] . "\">reply</span><span class=\"logs_date\">" . date("M j G:i", $chat['post_date']) . "</span></p></div><div class=\"clear\"></div></li>\n";								
												}
												else{
													echo "<li class=\"ch_logs $lcolor " . $chat['type'] . "\"><div value=\"" . $chat['post_user'] . "\" class=\"my_avatar chat_avatar_wrap\">$avatar</div><div class=\"my_text\"><p><span class=\"username " . $chat['post_color'] . "\">" . $chat['post_user'] . "</span> : $message<span class=\"logs_date\">" . date("M j G:i", $chat['post_date']) . "</span><span class=\"delete_log\" value=\"" . $chat['post_id'] . "\">x</span></p></div><div class=\"clear\"></div></li>\n";								
												}
										}
										else {
												if( strtolower($chat['post_target']) == strtolower($user['user_name']) && $chat['post_user'] != "$lang_system"){
													echo "<li class=\"ch_logs $lcolor " . $chat['type'] . "\"><div value=\"" . $chat['post_user'] . "\" class=\"my_avatar chat_avatar_wrap\">$avatar</div><div class=\"my_text\"><p><span class=\"username " . $chat['post_color'] . "\">" . $chat['post_user'] . "</span> : $message<span class=\"private_reply\" value=\"" . $chat['post_user'] . "\">reply</span><span class=\"logs_date\">" . date("M j G:i", $chat['post_date']) . "</span></p></div><div class=\"clear\"></div></li>\n";								
												}
												else{
													echo "<li class=\"ch_logs $lcolor " . $chat['type'] . "\"><div value=\"" . $chat['post_user'] . "\" class=\"my_avatar chat_avatar_wrap\">$avatar</div><div class=\"my_text\"><p><span class=\"username " . $chat['post_color'] . "\">" . $chat['post_user'] . "</span> : $message<span class=\"logs_date\">" . date("M j G:i", $chat['post_date']) . "</span></p></div><div class=\"clear\"></div></li>\n";								
												}
										}
										if($logs == 1){
											$logs = 2;
										}
										else {
											$logs = 1;
										}
									}
							}
							
						}
						else {
							echo "<li class=\"ch_logs system\"><div class=\"my_avatar chat_avatar_wrap\"><img class=\"avatar_chat\" src=\"avatar/default_system_tumb.png\"/></div><div class=\"my_text\"><p><span class=\"username csystem\">$lang_system</span> : $notext<span class=\"logs_date\">" . date("M j G:i", $time) . "</span></p></div><div class=\"clear\"></div></li>\n";
						}
				}
				else {
					echo 2;
				}
			}
			else{
				echo 99;
			}
		}
		else {
			echo 1;
		}
	}
	else{
		echo "$lang_error";
	}
?>